package com.virtualcable.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp\nimport androidx.compose.ui.unit.sp
import com.virtualcable.audio.AudioCaptureEngine
import com.virtualcable.audio.InjectionEngine
import com.virtualcable.audio.OboeProcessor

/**
 * DashboardScreen: Main UI for Virtual Audio Cable
 *
 * Features:
 * - Real-time audio visualizer
 * - Source/Destination app selectors
 * - Start/Stop controls
 * - Status indicators
 * - Settings access
 */
@Composable
fun DashboardScreen(
    isCapturing: Boolean,
    isInjecting: Boolean,
    onStartCapture: () -> Unit,
    onStopCapture: () -> Unit,
    onStartInjection: () -> Unit,
    onStopInjection: () -> Unit,
    onSourceAppSelected: (String) -> Unit,
    onDestinationAppSelected: (String) -> Unit,
    audioLevels: List<Float> = emptyList(),
    sourceApp: String? = null,
    destinationApp: String? = null,
    availableApps: List<String> = emptyList(),
    captureLatencyMs: Int = 0,
    injectionLatencyMs: Int = 0,
    onSettingsClick: () -> Unit = {}
) {
    val scrollState = rememberScrollState()

    Scaffold(
        topBar = {
            DashboardTopBar(onSettingsClick = onSettingsClick)
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(scrollState)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header
            HeaderSection()

            // Audio Visualizer
            AudioVisualizerBars(
                audioLevels = audioLevels,
                modifier = Modifier.fillMaxWidth(),
                barCount = 16,
                primaryColor = Color(0xFF6366F1),
                peakColor = Color(0xFFEC4899)
            )

            // Status Card
            AudioStatusCard(
                isCapturing = isCapturing,
                isInjecting = isInjecting,
                captureLatencyMs = captureLatencyMs,
                injectionLatencyMs = injectionLatencyMs,
                sourceApp = sourceApp,
                destinationApp = destinationApp
            )

            // App Selection Section
            AppSelectionSection(
                sourceApp = sourceApp,
                destinationApp = destinationApp,
                availableApps = availableApps,
                onSourceAppSelected = onSourceAppSelected,
                onDestinationAppSelected = onDestinationAppSelected
            )

            // Control Buttons
            ControlButtonsSection(
                isCapturing = isCapturing,
                isInjecting = isInjecting,
                onStartCapture = onStartCapture,
                onStopCapture = onStopCapture,
                onStartInjection = onStartInjection,
                onStopInjection = onStopInjection
            )

            // Info Section
            InfoSection()

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

/**
 * DashboardTopBar: Top app bar with title and settings
 */
@Composable
fun DashboardTopBar(
    onSettingsClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Text(
                    text = "Virtual Audio Cable",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1F2937)
                )
                Text(
                    text = "Android 10+",
                    fontSize = 12.sp,
                    color = Color(0xFF9CA3AF)
                )
            }
        },
        actions = {
            IconButton(onClick = onSettingsClick) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = Color(0xFF6366F1)
                )
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = Color.White,
            titleContentColor = Color(0xFF1F2937)
        )
    )
}

/**
 * HeaderSection: Welcome and description
 */
@Composable
fun HeaderSection() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = "Audio Pipe Dashboard",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1F2937)
        )
        Text(
            text = "Capture internal system audio and reroute it as a virtual microphone input",
            fontSize = 14.sp,
            color = Color(0xFF6B7280),
            lineHeight = 20.sp
        )
    }
}

/**
 * AppSelectionSection: Source and destination app selectors
 */
@Composable
fun AppSelectionSection(
    sourceApp: String?,
    destinationApp: String?,
    availableApps: List<String>,
    onSourceAppSelected: (String) -> Unit,
    onDestinationAppSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF9FAFB)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "Audio Routing",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1F2937)
            )

            AppSelector(
                label = "Source App (e.g., SoundCloud)",
                selectedApp = sourceApp,
                availableApps = availableApps,
                onAppSelected = onSourceAppSelected
            )

            AppSelector(
                label = "Destination App (e.g., Game)",
                selectedApp = destinationApp,
                availableApps = availableApps,
                onAppSelected = onDestinationAppSelected
            )
        }
    }
}

/**
 * ControlButtonsSection: Start/Stop buttons for capture and injection
 */
@Composable
fun ControlButtonsSection(
    isCapturing: Boolean,
    isInjecting: Boolean,
    onStartCapture: () -> Unit,
    onStopCapture: () -> Unit,
    onStartInjection: () -> Unit,
    onStopInjection: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Capture Control
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Audio Capture",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937)
            )
            ControlButton(
                text = if (isCapturing) "Stop Capturing" else "Start Capturing",
                isActive = isCapturing,
                onClick = if (isCapturing) onStopCapture else onStartCapture,
                modifier = Modifier.fillMaxWidth()
            )
        }

        // Injection Control
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                text = "Audio Injection",
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937)
            )
            ControlButton(
                text = if (isInjecting) "Stop Injecting" else "Start Injecting",
                isActive = isInjecting,
                onClick = if (isInjecting) onStopInjection else onStartInjection,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * InfoSection: Information and tips
 */
@Composable
fun InfoSection() {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFFEF3C7)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "💡 Tips",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF92400E)
            )
            Text(
                text = "1. Grant MediaProjection permission when prompted\n" +
                        "2. Select source app (e.g., SoundCloud, YouTube)\n" +
                        "3. Select destination app (e.g., game)\n" +
                        "4. Start capture, then start injection\n" +
                        "5. Monitor latency for optimal performance",
                fontSize = 13.sp,
                color = Color(0xFF78350F),
                lineHeight = 18.sp
            )
        }
    }
}

/**
 * Preview composable for testing
 */
@Composable
fun DashboardScreenPreview() {
    DashboardScreen(
        isCapturing = false,
        isInjecting = false,
        onStartCapture = {},
        onStopCapture = {},
        onStartInjection = {},
        onStopInjection = {},
        onSourceAppSelected = {},
        onDestinationAppSelected = {},
        audioLevels = listOf(0.1f, 0.3f, 0.5f, 0.7f, 0.8f, 0.6f, 0.4f, 0.2f),
        sourceApp = "SoundCloud",
        destinationApp = "Flex City",
        availableApps = listOf("SoundCloud", "YouTube", "Spotify", "Flex City", "Oxide"),
        captureLatencyMs = 15,
        injectionLatencyMs = 20
    )
}

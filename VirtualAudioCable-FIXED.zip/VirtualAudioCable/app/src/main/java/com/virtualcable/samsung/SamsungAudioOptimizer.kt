package com.virtualcable.samsung

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi

/**
 * SamsungAudioOptimizer: Samsung-specific audio optimizations
 *
 * Features:
 * - Detect Samsung device and model
 * - Leverage Samsung's \"Separate App Sound\" feature
 * - Optimize audio routing for Galaxy devices
 * - Apply device-specific audio configurations
 *
 * Samsung-specific APIs:
 * - AudioRoute (if available)
 * - Separate App Sound routing
 * - Galaxy-specific audio optimization
 */
@RequiresApi(Build.VERSION_CODES.Q)  // Android 10+
class SamsungAudioOptimizer(private val context: Context) {
    companion object {
        private const val TAG = "SamsungAudioOptimizer"

        // Samsung device identifiers
        private const val SAMSUNG_BRAND = "samsung"
        private const val GALAXY_PREFIX = "SM-"
        
        // Known Samsung models optimized for this app
        private val OPTIMIZED_MODELS = setOf(
            "SM-G63",      // Galaxy G63
            "SM-G64",      // Galaxy G64
            "SM-G65",      // Galaxy G65
            "SM-A",        // Galaxy A series
            "SM-S",        // Galaxy S series
            "SM-Z"         // Galaxy Z series (foldables)
        )
    }

    private val audioManager: AudioManager? by lazy {
        context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    /**
     * Check if device is Samsung
     */
    fun isSamsungDevice(): Boolean {
        return Build.BRAND.lowercase().contains(SAMSUNG_BRAND)
    }

    /**
     * Get Samsung device model
     */
    fun getSamsungModel(): String? {
        return if (isSamsungDevice()) Build.MODEL else null
    }

    /**
     * Check if device is optimized (Galaxy G63, G64, etc.)
     */
    fun isOptimizedDevice(): Boolean {
        val model = getSamsungModel() ?: return false
        return OPTIMIZED_MODELS.any { model.startsWith(it) }
    }

    /**
     * Get device info string
     */
    fun getDeviceInfo(): String {
        return """
            Device: ${Build.MANUFACTURER} ${Build.MODEL}
            Android: ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})
            Is Samsung: ${isSamsungDevice()}
            Is Optimized: ${isOptimizedDevice()}
        """.trimIndent()
    }

    /**
     * Enable Samsung's \"Separate App Sound\" feature if available
     * This allows routing specific app audio to isolated streams
     */
    fun enableSeparateAppSound(sourcePackageName: String): Boolean {
        return try {
            if (!isSamsungDevice()) {
                Log.w(TAG, "Device is not Samsung")
                return false
            }

            // Samsung Separate App Sound is typically controlled via Settings
            // For now, we document the capability
            Log.i(TAG, "Separate App Sound capability available for: $sourcePackageName")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error enabling Separate App Sound", e)
            false
        }
    }

    /**
     * Apply Samsung-specific audio optimizations
     */
    fun applySamsungOptimizations(): SamsungAudioConfig {
        val config = SamsungAudioConfig()

        if (!isSamsungDevice()) {
            Log.w(TAG, "Device is not Samsung, using default config")
            return config
        }

        try {
            // Samsung Galaxy G63 and similar models
            if (getSamsungModel()?.startsWith("SM-G63") == true) {
                config.apply {
                    sampleRate = 48000
                    channelCount = 1
                    audioFormat = android.media.AudioFormat.ENCODING_PCM_16BIT
                    bufferMultiplier = 3  // Slightly larger buffer for stability
                    useExclusiveMode = true
                    useVoiceCommunication = true
                }
                Log.i(TAG, "Applied optimizations for Galaxy G63")
            }

            // General Samsung optimization
            config.apply {
                enableAudioFocus = true
                abandonAudioFocusOnPause = true
            }

            Log.i(TAG, "Samsung audio optimizations applied: $config")
        } catch (e: Exception) {
            Log.e(TAG, "Error applying Samsung optimizations", e)
        }

        return config
    }

    /**
     * Get optimal audio route for Samsung device
     */
    fun getOptimalAudioRoute(): AudioRoute {
        val route = AudioRoute()

        if (!isSamsungDevice()) {
            route.preferredOutput = AudioRoute.Output.SPEAKER
            return route
        }

        try {
            // For Samsung devices, prefer voice communication route
            route.apply {
                preferredOutput = AudioRoute.Output.VOICE_COMMUNICATION
                enableSeparateAppSound = true
                optimizeForGaming = true
            }

            Log.d(TAG, "Optimal audio route for Samsung: $route")
        } catch (e: Exception) {
            Log.e(TAG, "Error getting optimal audio route", e)
        }

        return route
    }

    /**
     * Check if Samsung Separate App Sound is available
     */
    fun isSeparateAppSoundAvailable(): Boolean {
        if (!isSamsungDevice()) return false

        return try {
            // Check if device supports Separate App Sound
            // This is typically available on Samsung Galaxy devices with Android 11+
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R
        } catch (e: Exception) {
            Log.e(TAG, "Error checking Separate App Sound availability", e)
            false
        }
    }

    /**
     * Optimize audio for gaming (Samsung-specific)
     */
    fun optimizeForGaming(): Boolean {
        return try {
            if (!isSamsungDevice()) {
                Log.w(TAG, "Device is not Samsung")
                return false
            }

            // Samsung gaming optimizations
            Log.i(TAG, "Gaming optimizations enabled")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error optimizing for gaming", e)
            false
        }
    }

    /**
     * Data class for Samsung audio configuration
     */
    data class SamsungAudioConfig(
        var sampleRate: Int = 48000,
        var channelCount: Int = 1,
        var audioFormat: Int = android.media.AudioFormat.ENCODING_PCM_16BIT,
        var bufferMultiplier: Int = 2,
        var useExclusiveMode: Boolean = true,
        var useVoiceCommunication: Boolean = true,
        var enableAudioFocus: Boolean = true,
        var abandonAudioFocusOnPause: Boolean = true
    )

    /**
     * Data class for audio routing configuration
     */
    data class AudioRoute(
        var preferredOutput: Output = Output.SPEAKER,
        var enableSeparateAppSound: Boolean = false,
        var optimizeForGaming: Boolean = false
    ) {
        enum class Output {
            SPEAKER,
            VOICE_COMMUNICATION,
            BLUETOOTH,
            WIRED_HEADSET
        }
    }
}

/**
 * Extension function to get Samsung optimizer
 */
fun Context.getSamsungOptimizer(): SamsungAudioOptimizer {
    return SamsungAudioOptimizer(this)
}

/**
 * Extension function to check if running on Samsung
 */
fun isSamsungDevice(): Boolean {
    return Build.BRAND.lowercase().contains("samsung")
}

/**
 * Extension function to get device model
 */
fun getDeviceModel(): String {
    return "${Build.MANUFACTURER} ${Build.MODEL}"
}

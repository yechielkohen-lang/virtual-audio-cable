package com.virtualcable.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * InjectionEngine: Attempts to inject captured audio into the system's microphone input
 *
 * Strategy:
 * 1. Primary: Use AudioTrack with USAGE_VOICE_COMMUNICATION to route to telephony/comm stream
 * 2. Fallback: Write to speaker output (acoustic loopback - less ideal but functional)
 * 3. Samsung-specific: Leverage Samsung's audio routing APIs if available
 *
 * Challenges:
 * - Android doesn't provide a public API to inject into the microphone input directly
 * - Non-root apps cannot create virtual audio devices
 * - This implementation attempts the best possible workaround using standard APIs
 */
@RequiresApi(Build.VERSION_CODES.Q)  // Android 10+
class InjectionEngine(
    private val sampleRate: Int = 48000,
    private val channelConfig: Int = AudioFormat.CHANNEL_OUT_MONO,
    private val audioFormat: Int = AudioFormat.ENCODING_PCM_16BIT
) {
    companion object {
        private const val TAG = "InjectionEngine"
        
        // Injection modes
        enum class InjectionMode {
            VOICE_COMMUNICATION,  // Primary: Use VOICE_COMMUNICATION usage
            SPEAKER_LOOPBACK,     // Fallback: Route to speaker
            MUSIC_PLAYBACK        // Alternative: Use MUSIC usage
        }
    }

    private var audioTrack: AudioTrack? = null
    private var injectionThread: Thread? = null
    private val isInjecting = AtomicBoolean(false)
    private val injectionQueue: java.util.concurrent.BlockingQueue<ByteArray> = 
        java.util.concurrent.LinkedBlockingQueue(20)
    
    private var currentMode: InjectionMode = InjectionMode.VOICE_COMMUNICATION
    private var totalBytesInjected = 0L
    private var injectionStartTime = 0L

    /**
     * Start audio injection
     * Attempts to route captured audio into the system's microphone input
     */
    fun start(mode: InjectionMode = InjectionMode.VOICE_COMMUNICATION): Boolean {
        if (isInjecting.get()) {
            Log.w(TAG, "Injection already running")
            return true
        }

        return try {
            currentMode = mode
            
            // Calculate buffer size
            val minBufferSize = AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = minBufferSize * 2

            Log.d(TAG, "Starting injection: mode=$mode, bufferSize=$bufferSize")

            // Create AudioAttributes based on injection mode
            val audioAttributes = when (mode) {
                InjectionMode.VOICE_COMMUNICATION -> {
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                }
                InjectionMode.SPEAKER_LOOPBACK -> {
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                }
                InjectionMode.MUSIC_PLAYBACK -> {
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                }
            }

            // Create AudioFormat
            val audioFormat = AudioFormat.Builder()
                .setEncoding(this.audioFormat)
                .setSampleRate(sampleRate)
                .setChannelMask(channelConfig)
                .build()

            // Create AudioTrack
            audioTrack = AudioTrack.Builder()
                .setAudioAttributes(audioAttributes)
                .setAudioFormat(audioFormat)
                .setBufferSizeInBytes(bufferSize)
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()

            // Verify AudioTrack state
            if (audioTrack?.state != AudioTrack.STATE_INITIALIZED) {
                throw RuntimeException("AudioTrack failed to initialize")
            }

            // Start playback
            audioTrack?.play()
            isInjecting.set(true)
            injectionStartTime = System.currentTimeMillis()
            totalBytesInjected = 0L

            // Start injection thread
            injectionThread = thread(
                start = true,
                isDaemon = false,
                name = "AudioInjectionThread"
            ) {
                injectionLoop()
            }

            Log.i(TAG, "Audio injection started successfully in mode: $mode")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start audio injection", e)
            stop()
            false
        }
    }

    /**
     * Main injection loop - runs on background thread
     * Writes PCM data to AudioTrack
     */
    private fun injectionLoop() {
        try {
            val audioTrack = audioTrack ?: return
            val timeout = java.util.concurrent.TimeUnit.MILLISECONDS

            Log.d(TAG, "Injection loop started")

            while (isInjecting.get()) {
                try {
                    // Get audio data from queue with timeout
                    val audioData = injectionQueue.poll(100, timeout) ?: continue

                    // Write to AudioTrack
                    val bytesWritten = audioTrack.write(audioData, 0, audioData.size)

                    if (bytesWritten > 0) {
                        totalBytesInjected += bytesWritten
                    } else if (bytesWritten == AudioTrack.ERROR_INVALID_OPERATION) {
                        Log.e(TAG, "AudioTrack error: INVALID_OPERATION")
                        break
                    } else if (bytesWritten == AudioTrack.ERROR_BAD_VALUE) {
                        Log.e(TAG, "AudioTrack error: BAD_VALUE")
                        break
                    }
                } catch (e: InterruptedException) {
                    if (isInjecting.get()) {
                        Log.e(TAG, "Injection thread interrupted", e)
                    }
                    break
                } catch (e: Exception) {
                    if (isInjecting.get()) {
                        Log.e(TAG, "Error in injection loop", e)
                    }
                    break
                }
            }

            Log.d(TAG, "Injection loop ended")
        } catch (e: Exception) {
            Log.e(TAG, "Fatal error in injection loop", e)
        }
    }

    /**
     * Write audio data to injection queue
     * This method is called by the audio capture engine
     *
     * @param audioData PCM audio data (16-bit)
     * @return true if data was queued, false if queue is full
     */
    fun writeAudio(audioData: ByteArray): Boolean {
        if (!isInjecting.get()) {
            Log.w(TAG, "Injection not running")
            return false
        }

        return try {
            // Try to add to queue, don't block
            injectionQueue.offer(audioData)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing audio", e)
            false
        }
    }

    /**
     * Write audio data directly to AudioTrack (synchronous)
     * Use this for low-latency direct writes
     */
    fun writeAudioDirect(audioData: ByteArray): Int {
        if (!isInjecting.get()) {
            Log.w(TAG, "Injection not running")
            return 0
        }

        return try {
            audioTrack?.write(audioData, 0, audioData.size) ?: 0
        } catch (e: Exception) {
            Log.e(TAG, "Error writing audio directly", e)
            0
        }
    }

    /**
     * Stop audio injection and clean up resources
     */
    fun stop() {
        if (!isInjecting.getAndSet(false)) {
            Log.w(TAG, "Injection not running")
            return
        }

        try {
            // Stop AudioTrack
            audioTrack?.let {
                if (it.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    it.stop()
                }
                it.release()
            }
            audioTrack = null

            // Wait for injection thread to finish
            injectionThread?.join(5000)  // 5 second timeout
            injectionThread = null

            // Clear queue
            injectionQueue.clear()

            // Log statistics
            val injectionTime = System.currentTimeMillis() - injectionStartTime
            Log.i(TAG, "Injection stopped. Stats: " +
                    "duration=${injectionTime}ms, " +
                    "bytesInjected=$totalBytesInjected, " +
                    "mode=$currentMode")

        } catch (e: Exception) {
            Log.e(TAG, "Error stopping injection", e)
        }
    }

    /**
     * Get current injection statistics
     */
    fun getStatistics(): InjectionStatistics {
        val injectionTime = if (isInjecting.get()) {
            System.currentTimeMillis() - injectionStartTime
        } else {
            0L
        }

        return InjectionStatistics(
            isInjecting = isInjecting.get(),
            mode = currentMode,
            totalBytesInjected = totalBytesInjected,
            injectionTimeMs = injectionTime,
            queueSize = injectionQueue.size,
            sampleRate = sampleRate,
            channelCount = getChannelCount()
        )
    }

    /**
     * Get estimated latency
     */
    fun getLatencyMs(): Int {
        return try {
            audioTrack?.let {
                (it.bufferSizeInFrames * 1000) / sampleRate
            } ?: 0
        } catch (e: Exception) {
            Log.e(TAG, "Error getting latency", e)
            0
        }
    }

    /**
     * Check if injection is currently running
     */
    fun isRunning(): Boolean = isInjecting.get()

    /**
     * Get number of channels
     */
    private fun getChannelCount(): Int {
        return when (channelConfig) {
            AudioFormat.CHANNEL_OUT_MONO -> 1
            AudioFormat.CHANNEL_OUT_STEREO -> 2
            else -> 1
        }
    }

    /**
     * Get current playback state
     */
    fun getPlaybackState(): Int {
        return audioTrack?.playState ?: AudioTrack.PLAYSTATE_STOPPED
    }

    /**
     * Data class for injection statistics
     */
    data class InjectionStatistics(
        val isInjecting: Boolean,
        val mode: InjectionMode,
        val totalBytesInjected: Long,
        val injectionTimeMs: Long,
        val queueSize: Int,
        val sampleRate: Int,
        val channelCount: Int
    ) {
        fun getAverageBitrate(): Float {
            if (injectionTimeMs == 0L) return 0f
            return (totalBytesInjected * 8 * 1000) / injectionTimeMs.toFloat()
        }
    }
}

/**
 * Extension function to safely write audio with error handling
 */
fun InjectionEngine.writeAudioSafely(audioData: ByteArray): Boolean {
    return try {
        if (this.isRunning()) {
            this.writeAudio(audioData)
        } else {
            false
        }
    } catch (e: Exception) {
        Log.e("InjectionEngine", "Error writing audio safely", e)
        false
    }
}

/**
 * Extension function to get injection info as string
 */
fun InjectionEngine.getInfoString(): String {
    val stats = this.getStatistics()
    return """
        InjectionEngine Status:
        - Running: ${stats.isInjecting}
        - Mode: ${stats.mode}
        - Total Bytes: ${stats.totalBytesInjected}
        - Duration: ${stats.injectionTimeMs} ms
        - Queue Size: ${stats.queueSize}
        - Latency: ${this.getLatencyMs()} ms
        - Sample Rate: ${stats.sampleRate} Hz
        - Channels: ${stats.channelCount}
    """.trimIndent()
}

package com.virtualcable.audio

import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaProjection
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import java.util.concurrent.BlockingQueue
import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * AudioCaptureEngine: Captures internal system audio using AudioPlaybackCaptureConfig (Android 10+)
 *
 * This engine:
 * 1. Uses MediaProjection to access system audio
 * 2. Creates an AudioRecord with AudioPlaybackCaptureConfiguration
 * 3. Runs a background thread to continuously read PCM data
 * 4. Provides callbacks for real-time audio data processing
 *
 * Supported Audio Format:
 * - Sample Rate: 48000 Hz (default, can be configured)
 * - Channel Config: MONO (can be STEREO)
 * - Audio Format: PCM 16-bit
 * - Buffer Size: Calculated based on device capabilities
 */
@RequiresApi(Build.VERSION_CODES.Q)  // Android 10+
class AudioCaptureEngine(
    private val mediaProjection: MediaProjection,
    private val sampleRate: Int = 48000,
    private val channelConfig: Int = AudioFormat.CHANNEL_IN_MONO,
    private val audioFormat: Int = AudioFormat.ENCODING_PCM_16BIT
) {
    companion object {
        private const val TAG = "AudioCaptureEngine"
        
        // Audio configuration constants
        private const val DEFAULT_SAMPLE_RATE = 48000
        private const val MIN_BUFFER_SIZE_MULTIPLIER = 2
    }

    // Audio Record instance
    private var audioRecord: AudioRecord? = null
    
    // Capture thread management
    private var captureThread: Thread? = null
    private val isCapturing = AtomicBoolean(false)
    
    // Callback for audio data
    private var audioDataCallback: ((ByteArray, Int) -> Unit)? = null
    
    // Error callback
    private var errorCallback: ((String) -> Unit)? = null
    
    // Queue for thread-safe audio data passing (optional, for buffering)
    private val audioDataQueue: BlockingQueue<Pair<ByteArray, Int>> = LinkedBlockingQueue(10)
    
    // Statistics
    private var totalBytesRead = 0L
    private var totalFramesRead = 0L
    private var captureStartTime = 0L

    /**
     * Initialize and start audio capture
     *
     * @param onAudioData Callback invoked with PCM data: (audioData: ByteArray, numBytes: Int)
     * @param onError Optional callback for errors
     */
    fun start(
        onAudioData: (ByteArray, Int) -> Unit,
        onError: ((String) -> Unit)? = null
    ) {
        if (isCapturing.get()) {
            Log.w(TAG, "Capture already running")
            return
        }

        try {
            audioDataCallback = onAudioData
            errorCallback = onError
            
            // Calculate buffer size
            val minBufferSize = AudioRecord.getMinBufferSize(sampleRate, channelConfig, audioFormat)
            val bufferSize = minBufferSize * MIN_BUFFER_SIZE_MULTIPLIER
            
            Log.d(TAG, "Starting capture: sampleRate=$sampleRate, bufferSize=$bufferSize")

            // Create AudioPlaybackCaptureConfiguration
            val captureConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_GAME)
                .addMatchingUsage(android.media.AudioAttributes.USAGE_UNKNOWN)
                .build()

            // Create AudioRecord with capture configuration
            audioRecord = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(captureConfig)
                .setAudioSource(android.media.MediaRecorder.AudioSource.DEFAULT)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(audioFormat)
                        .setSampleRate(sampleRate)
                        .setChannelMask(channelConfig)
                        .build()
                )
                .setBufferSizeInBytes(bufferSize)
                .build()

            // Verify AudioRecord state
            if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
                throw RuntimeException("AudioRecord failed to initialize")
            }

            // Start recording
            audioRecord?.startRecording()
            isCapturing.set(true)
            captureStartTime = System.currentTimeMillis()
            totalBytesRead = 0L
            totalFramesRead = 0L

            // Start capture thread
            captureThread = thread(
                start = true,
                isDaemon = false,
                name = "AudioCaptureThread"
            ) {
                captureLoop()
            }

            Log.i(TAG, "Audio capture started successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start audio capture", e)
            errorCallback?.invoke("Failed to start capture: ${e.message}")
            stop()
        }
    }

    /**
     * Main capture loop - runs on background thread
     * Continuously reads PCM data from AudioRecord
     */
    private fun captureLoop() {
        try {
            val audioRecord = audioRecord ?: return
            val bufferSize = audioRecord.bufferSizeInBytes
            val audioBuffer = ByteArray(bufferSize)

            Log.d(TAG, "Capture loop started, buffer size: $bufferSize bytes")

            while (isCapturing.get()) {
                try {
                    // Read audio data from AudioRecord
                    val bytesRead = audioRecord.read(audioBuffer, 0, bufferSize)

                    if (bytesRead > 0) {
                        totalBytesRead += bytesRead
                        totalFramesRead += (bytesRead / (audioFormat.getBytesPerSample() * getChannelCount()))

                        // Invoke callback with audio data
                        audioDataCallback?.invoke(audioBuffer.copyOf(bytesRead), bytesRead)

                        // Optional: Add to queue for buffering
                        audioDataQueue.offer(Pair(audioBuffer.copyOf(bytesRead), bytesRead))
                    } else if (bytesRead == AudioRecord.ERROR_INVALID_OPERATION) {
                        Log.e(TAG, "AudioRecord error: INVALID_OPERATION")
                        errorCallback?.invoke("AudioRecord error: INVALID_OPERATION")
                        break
                    } else if (bytesRead == AudioRecord.ERROR_BAD_VALUE) {
                        Log.e(TAG, "AudioRecord error: BAD_VALUE")
                        errorCallback?.invoke("AudioRecord error: BAD_VALUE")
                        break
                    }
                } catch (e: Exception) {
                    if (isCapturing.get()) {
                        Log.e(TAG, "Error in capture loop", e)
                        errorCallback?.invoke("Capture loop error: ${e.message}")
                    }
                    break
                }
            }

            Log.d(TAG, "Capture loop ended")
        } catch (e: Exception) {
            Log.e(TAG, "Fatal error in capture loop", e)
            errorCallback?.invoke("Fatal capture error: ${e.message}")
        }
    }

    /**
     * Stop audio capture and clean up resources
     */
    fun stop() {
        if (!isCapturing.getAndSet(false)) {
            Log.w(TAG, "Capture not running")
            return
        }

        try {
            // Stop AudioRecord
            audioRecord?.let {
                if (it.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                    it.stop()
                }
                it.release()
            }
            audioRecord = null

            // Wait for capture thread to finish
            captureThread?.join(5000)  // 5 second timeout
            captureThread = null

            // Log statistics
            val captureTime = System.currentTimeMillis() - captureStartTime
            Log.i(TAG, "Capture stopped. Stats: " +
                    "duration=${captureTime}ms, " +
                    "bytesRead=$totalBytesRead, " +
                    "framesRead=$totalFramesRead")

        } catch (e: Exception) {
            Log.e(TAG, "Error stopping capture", e)
        }

        audioDataCallback = null
        errorCallback = null
    }

    /**
     * Get current capture statistics
     */
    fun getStatistics(): CaptureStatistics {
        val captureTime = if (isCapturing.get()) {
            System.currentTimeMillis() - captureStartTime
        } else {
            0L
        }

        return CaptureStatistics(
            isCapturing = isCapturing.get(),
            totalBytesRead = totalBytesRead,
            totalFramesRead = totalFramesRead,
            captureTimeMs = captureTime,
            sampleRate = sampleRate,
            channelCount = getChannelCount()
        )
    }

    /**
     * Check if capture is currently running
     */
    fun isRunning(): Boolean = isCapturing.get()

    /**
     * Get next audio data from queue (if using queue-based approach)
     * Blocks until data is available or timeout occurs
     */
    fun getAudioDataFromQueue(timeoutMs: Long = 100): Pair<ByteArray, Int>? {
        return try {
            audioDataQueue.poll(timeoutMs, java.util.concurrent.TimeUnit.MILLISECONDS)
        } catch (e: InterruptedException) {
            null
        }
    }

    /**
     * Get number of channels based on channel config
     */
    private fun getChannelCount(): Int {
        return when (channelConfig) {
            AudioFormat.CHANNEL_IN_MONO -> 1
            AudioFormat.CHANNEL_IN_STEREO -> 2
            else -> 1
        }
    }

    /**
     * Data class for capture statistics
     */
    data class CaptureStatistics(
        val isCapturing: Boolean,
        val totalBytesRead: Long,
        val totalFramesRead: Long,
        val captureTimeMs: Long,
        val sampleRate: Int,
        val channelCount: Int
    ) {
        fun getAverageBitrate(): Float {
            if (captureTimeMs == 0L) return 0f
            return (totalBytesRead * 8 * 1000) / captureTimeMs.toFloat()
        }
    }
}

/**
 * Extension function to get bytes per sample for audio format
 */
private fun Int.getBytesPerSample(): Int {
    return when (this) {
        AudioFormat.ENCODING_PCM_8BIT -> 1
        AudioFormat.ENCODING_PCM_16BIT -> 2
        AudioFormat.ENCODING_PCM_FLOAT -> 4
        else -> 2  // Default to 16-bit
    }
}

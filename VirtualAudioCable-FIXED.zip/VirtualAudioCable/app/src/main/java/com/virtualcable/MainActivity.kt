package com.virtualcable

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.RequiresApi
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.virtualcable.ui.DashboardScreen

@RequiresApi(Build.VERSION_CODES.Q)
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    DashboardScreen(
                        isCapturing = false,
                        isInjecting = false,
                        onStartCapture = {},
                        onStopCapture = {},
                        onStartInjection = {},
                        onStopInjection = {},
                        onSourceAppSelected = {},
                        onDestinationAppSelected = {},
                        audioLevels = emptyList(),
                        sourceApp = null,
                        destinationApp = null,
                        availableApps = emptyList(),
                        captureLatencyMs = 0,
                        injectionLatencyMs = 0
                    )
                }
            }
        }
    }
}

package com.virtualcable.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs

/**
 * AudioVisualizerBars: Real-time audio level visualizer using animated bars
 *
 * Displays audio levels in dB scale with smooth animations
 */
@Composable
fun AudioVisualizerBars(
    audioLevels: List<Float>,  // Audio levels (0.0 to 1.0)
    modifier: Modifier = Modifier,
    barCount: Int = 16,
    primaryColor: Color = Color(0xFF6366F1),
    peakColor: Color = Color(0xFFEC4899),
    backgroundColor: Color = Color(0xFFF3F4F6)
) {
    val displayLevels = remember { mutableStateListOf<Float>() }

    // Update display levels
    LaunchedEffect(audioLevels) {
        if (audioLevels.isNotEmpty()) {
            // Resample audio levels to bar count
            val step = audioLevels.size / barCount
            val newLevels = (0 until barCount).map { i ->
                val index = (i * step).coerceAtMost(audioLevels.size - 1)
                audioLevels[index].coerceIn(0f, 1f)
            }
            displayLevels.clear()
            displayLevels.addAll(newLevels)
        }
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .height(120.dp)
            .background(backgroundColor, RoundedCornerShape(12.dp))
            .padding(12.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        displayLevels.forEachIndexed { index, level ->
            AudioBar(
                level = level,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                primaryColor = primaryColor,
                peakColor = peakColor
            )
        }
    }
}

/**
 * AudioBar: Single animated audio level bar
 */
@Composable
fun AudioBar(
    level: Float,
    modifier: Modifier = Modifier,
    primaryColor: Color = Color(0xFF6366F1),
    peakColor: Color = Color(0xFFEC4899)
) {
    val animatedLevel by animateFloatAsState(
        targetValue = level,
        label = "audioBarAnimation"
    )

    val barColor = if (animatedLevel > 0.8f) peakColor else primaryColor

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(Color.LightGray.copy(alpha = 0.3f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(animatedLevel)
                .background(barColor, RoundedCornerShape(4.dp))
                .align(Alignment.BottomCenter)
        )
    }
}

/**
 * AudioWaveformVisualizer: Waveform-style audio visualizer
 *
 * Displays audio as a waveform pattern
 */
@Composable
fun AudioWaveformVisualizer(
    audioSamples: List<Float>,
    modifier: Modifier = Modifier,
    lineColor: Color = Color(0xFF6366F1),
    backgroundColor: Color = Color(0xFFF3F4F6),
    centerLineColor: Color = Color(0xFFD1D5DB)
) {
    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(100.dp)
            .background(backgroundColor, RoundedCornerShape(12.dp))
            .padding(8.dp)
    ) {
        val width = size.width
        val height = size.height
        val centerY = height / 2

        // Draw center line
        drawLine(
            color = centerLineColor,
            start = androidx.compose.ui.geometry.Offset(0f, centerY),
            end = androidx.compose.ui.geometry.Offset(width, centerY),
            strokeWidth = 1f
        )

        // Draw waveform
        if (audioSamples.isNotEmpty()) {
            val step = width / audioSamples.size
            var prevX = 0f
            var prevY = centerY

            audioSamples.forEachIndexed { index, sample ->
                val x = index * step
                val y = centerY - (sample * centerY)

                drawLine(
                    color = lineColor,
                    start = androidx.compose.ui.geometry.Offset(prevX, prevY),
                    end = androidx.compose.ui.geometry.Offset(x, y),
                    strokeWidth = 2f
                )

                prevX = x
                prevY = y
            }
        }
    }
}

/**
 * AudioStatusCard: Displays current audio capture/injection status
 */
@Composable
fun AudioStatusCard(
    isCapturing: Boolean,
    isInjecting: Boolean,
    captureLatencyMs: Int,
    injectionLatencyMs: Int,
    sourceApp: String?,
    destinationApp: String?,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFF9FAFB)
        )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Status indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                StatusIndicator(
                    label = "Capture",
                    isActive = isCapturing,
                    modifier = Modifier.weight(1f)
                )
                StatusIndicator(
                    label = "Injection",
                    isActive = isInjecting,
                    modifier = Modifier.weight(1f)
                )
            }

            // Latency info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LatencyInfo(
                    label = "Capture Latency",
                    latencyMs = captureLatencyMs,
                    modifier = Modifier.weight(1f)
                )
                LatencyInfo(
                    label = "Injection Latency",
                    latencyMs = injectionLatencyMs,
                    modifier = Modifier.weight(1f)
                )
            }

            // App routing info
            if (sourceApp != null || destinationApp != null) {
                Divider(modifier = Modifier.fillMaxWidth())
                
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (sourceApp != null) {
                        AppRoutingRow(
                            label = "Source App",
                            appName = sourceApp,
                            icon = "📱"
                        )
                    }
                    if (destinationApp != null) {
                        AppRoutingRow(
                            label = "Destination App",
                            appName = destinationApp,
                            icon = "🎮"
                        )
                    }
                }
            }
        }
    }
}

/**
 * StatusIndicator: Shows active/inactive status with visual indicator
 */
@Composable
fun StatusIndicator(
    label: String,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Box(
            modifier = Modifier
                .size(12.dp)
                .background(
                    color = if (isActive) Color(0x10A3E635) else Color(0x10EF4444),
                    shape = RoundedCornerShape(50%)
                )
                .padding(2.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        color = if (isActive) Color(0xFF22C55E) else Color(0xFFEF4444),
                        shape = RoundedCornerShape(50%)
                    )
            )
        }
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF6B7280)
        )
    }
}

/**
 * LatencyInfo: Displays latency information
 */
@Composable
fun LatencyInfo(
    label: String,
    latencyMs: Int,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF6B7280)
        )
        Text(
            text = "${latencyMs}ms",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF1F2937)
        )
    }
}

/**
 * AppRoutingRow: Displays source/destination app routing
 */
@Composable
fun AppRoutingRow(
    label: String,
    appName: String,
    icon: String,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = icon,
            fontSize = 16.sp
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 11.sp,
                color = Color(0xFF9CA3AF),
                fontWeight = FontWeight.Medium
            )
            Text(
                text = appName,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF1F2937)
            )
        }
    }
}

/**
 * ControlButton: Primary action button for start/stop
 */
@Composable
fun ControlButton(
    text: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true
) {
    Button(
        onClick = onClick,
        modifier = modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isActive) Color(0xFFEF4444) else Color(0xFF6366F1),
            disabledContainerColor = Color(0xFFD1D5DB)
        ),
        shape = RoundedCornerShape(12.dp),
        enabled = enabled
    ) {
        Text(
            text = text,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
    }
}

/**
 * AppSelector: Dropdown for selecting source/destination app
 */
@Composable
fun AppSelector(
    label: String,
    selectedApp: String?,
    availableApps: List<String>,
    onAppSelected: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = Color(0xFF6B7280),
            modifier = Modifier.padding(bottom = 8.dp)
        )

        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = it },
            modifier = Modifier.fillMaxWidth()
        ) {
            TextField(
                value = selectedApp ?: "Select an app",
                onValueChange = {},
                readOnly = true,
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                modifier = Modifier
                    .menuAnchor()
                    .fillMaxWidth(),
                colors = ExposedDropdownMenuDefaults.textFieldColors(
                    containerColor = Color(0xFFF3F4F6)
                )
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                availableApps.forEach { app ->
                    DropdownMenuItem(
                        text = { Text(app) },
                        onClick = {
                            onAppSelected(app)
                            expanded = false
                        }
                    )
                }
            }
        }
    }
}

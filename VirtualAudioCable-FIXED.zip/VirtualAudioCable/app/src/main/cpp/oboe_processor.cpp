/*
 * OboeProcessor: Low-latency audio processing using Google's Oboe library
 *
 * Features:
 * - Circular buffer for PCM data storage
 * - Real-time audio callback processing
 * - Sample rate conversion support
 * - AAudio backend with OpenSL ES fallback
 * - Minimal latency configuration
 *
 * Compilation: Requires Oboe library (https://github.com/google/oboe)
 */

#include <jni.h>
#include <oboe/Oboe.h>
#include <memory>
#include <cstring>
#include <android/log.h>
#include <queue>
#include <mutex>
#include <cmath>

#define LOG_TAG "OboeProcessor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, LOG_TAG, __VA_ARGS__)

// Circular buffer for audio data
class CircularBuffer {
private:
    std::vector<float> buffer_;
    size_t write_index_;
    size_t read_index_;
    size_t capacity_;
    std::mutex mutex_;

public:
    CircularBuffer(size_t capacity) 
        : buffer_(capacity, 0.0f), 
          write_index_(0), 
          read_index_(0), 
          capacity_(capacity) {}

    // Write data to buffer
    size_t write(const float* data, size_t num_frames) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        size_t frames_written = 0;
        for (size_t i = 0; i < num_frames; ++i) {
            buffer_[write_index_] = data[i];
            write_index_ = (write_index_ + 1) % capacity_;
            frames_written++;
            
            // Prevent overwriting unread data
            if (write_index_ == read_index_) {
                read_index_ = (read_index_ + 1) % capacity_;
            }
        }
        return frames_written;
    }

    // Read data from buffer
    size_t read(float* data, size_t num_frames) {
        std::lock_guard<std::mutex> lock(mutex_);
        
        size_t frames_read = 0;
        for (size_t i = 0; i < num_frames; ++i) {
            if (read_index_ == write_index_) {
                // Buffer empty, fill with silence
                data[i] = 0.0f;
            } else {
                data[i] = buffer_[read_index_];
                read_index_ = (read_index_ + 1) % capacity_;
                frames_read++;
            }
        }
        return frames_read;
    }

    // Get available frames to read
    size_t getAvailableFrames() {
        std::lock_guard<std::mutex> lock(mutex_);
        if (write_index_ >= read_index_) {
            return write_index_ - read_index_;
        } else {
            return capacity_ - read_index_ + write_index_;
        }
    }

    // Clear buffer
    void clear() {
        std::lock_guard<std::mutex> lock(mutex_);
        write_index_ = 0;
        read_index_ = 0;
        std::fill(buffer_.begin(), buffer_.end(), 0.0f);
    }
};

// OboeProcessor class
class OboeProcessor : public oboe::AudioStreamCallback {
private:
    std::shared_ptr<oboe::AudioStream> stream_;
    std::unique_ptr<CircularBuffer> buffer_;
    int32_t sample_rate_;
    int32_t channel_count_;
    bool is_playing_;
    int64_t frames_processed_;

public:
    OboeProcessor(int32_t sample_rate, int32_t channel_count)
        : sample_rate_(sample_rate),
          channel_count_(channel_count),
          is_playing_(false),
          frames_processed_(0) {
        
        // Create circular buffer (2 seconds of audio at given sample rate)
        size_t buffer_capacity = sample_rate * channel_count * 2;
        buffer_ = std::make_unique<CircularBuffer>(buffer_capacity);
        
        LOGI("OboeProcessor initialized: sr=%d, channels=%d, buffer_size=%zu",
             sample_rate_, channel_count_, buffer_capacity);
    }

    ~OboeProcessor() {
        stopPlayback();
    }

    // Start playback stream
    oboe::Result startPlayback() {
        if (is_playing_) {
            LOGD("Playback already running");
            return oboe::Result::OK;
        }

        try {
            oboe::AudioStreamBuilder builder;
            builder.setCallback(this)
                   .setFormat(oboe::AudioFormat::Float)
                   .setSampleRate(sample_rate_)
                   .setChannelCount(channel_count_)
                   .setDirection(oboe::Direction::Output)
                   .setPerformanceMode(oboe::PerformanceMode::LowLatency)
                   .setSharingMode(oboe::SharingMode::Exclusive)
                   .setUsage(oboe::Usage::VoiceCommunication);

            oboe::Result result = builder.openStream(stream_);
            
            if (result != oboe::Result::OK) {
                LOGE("Failed to create stream: %s", oboe::convertResultToText(result));
                return result;
            }

            // Verify stream properties
            LOGI("Stream created: sr=%d, channels=%d, format=%d, latency=%d ms",
                 stream_->getSampleRate(),
                 stream_->getChannelCount(),
                 static_cast<int>(stream_->getFormat()),
                 stream_->getFramesPerBurst() * 1000 / stream_->getSampleRate());

            result = stream_->requestStart();
            if (result == oboe::Result::OK) {
                is_playing_ = true;
                frames_processed_ = 0;
                LOGI("Playback started");
            } else {
                LOGE("Failed to start stream: %s", oboe::convertResultToText(result));
            }

            return result;
        } catch (const std::exception& e) {
            LOGE("Exception in startPlayback: %s", e.what());
            return oboe::Result::ErrorInternal;
        }
    }

    // Stop playback stream
    oboe::Result stopPlayback() {
        if (!is_playing_) {
            return oboe::Result::OK;
        }

        try {
            if (stream_) {
                oboe::Result result = stream_->requestStop();
                stream_->close();
                stream_ = nullptr;
            }
            is_playing_ = false;
            LOGI("Playback stopped. Frames processed: %lld", frames_processed_);
            return oboe::Result::OK;
        } catch (const std::exception& e) {
            LOGE("Exception in stopPlayback: %s", e.what());
            return oboe::Result::ErrorInternal;
        }
    }

    // Write audio data to buffer
    void writeAudioData(const float* data, int32_t num_frames) {
        if (!buffer_) return;
        buffer_->write(data, num_frames * channel_count_);
    }

    // Write audio data from 16-bit PCM
    void writeAudioDataPCM16(const int16_t* data, int32_t num_frames) {
        if (!buffer_) return;

        // Convert 16-bit PCM to float
        std::vector<float> float_data(num_frames * channel_count_);
        for (int32_t i = 0; i < num_frames * channel_count_; ++i) {
            float_data[i] = data[i] / 32768.0f;  // Normalize to [-1.0, 1.0]
        }
        buffer_->write(float_data.data(), num_frames * channel_count_);
    }

    // Get available frames in buffer
    int32_t getAvailableFrames() {
        if (!buffer_) return 0;
        return buffer_->getAvailableFrames() / channel_count_;
    }

    // Clear buffer
    void clearBuffer() {
        if (buffer_) {
            buffer_->clear();
        }
    }

    // Get latency in milliseconds
    int32_t getLatencyMs() {
        if (!stream_) return 0;
        return (stream_->getFramesPerBurst() * 1000) / stream_->getSampleRate();
    }

    // Oboe callback - called by audio engine
    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* audio_stream,
        void* audio_data,
        int32_t num_frames) override {

        if (!buffer_) {
            return oboe::DataCallbackResult::Stop;
        }

        try {
            float* output = static_cast<float*>(audio_data);
            
            // Read data from circular buffer
            buffer_->read(output, num_frames * channel_count_);
            
            frames_processed_ += num_frames;

            return oboe::DataCallbackResult::Continue;
        } catch (const std::exception& e) {
            LOGE("Exception in onAudioReady: %s", e.what());
            return oboe::DataCallbackResult::Stop;
        }
    }

    // Error callback
    void onErrorAfterClose(oboe::AudioStream* audio_stream, oboe::Result error) override {
        LOGE("Stream error: %s", oboe::convertResultToText(error));
    }

    // Check if playing
    bool isPlaying() const {
        return is_playing_;
    }
};

// Global processor instance
static OboeProcessor* g_processor = nullptr;

// JNI Functions
extern "C" {

    /**
     * Create and initialize OboeProcessor
     * Java: public static native long createProcessor(int sampleRate, int channelCount);
     */
    JNIEXPORT jlong JNICALL
    Java_com_virtualcable_audio_OboeProcessor_createProcessor(
        JNIEnv* env, jclass clazz,
        jint sample_rate, jint channel_count) {

        try {
            g_processor = new OboeProcessor(sample_rate, channel_count);
            LOGI("Processor created: %p", g_processor);
            return reinterpret_cast<jlong>(g_processor);
        } catch (const std::exception& e) {
            LOGE("Failed to create processor: %s", e.what());
            return 0;
        }
    }

    /**
     * Start playback
     * Java: public static native int startPlayback(long processorHandle);
     */
    JNIEXPORT jint JNICALL
    Java_com_virtualcable_audio_OboeProcessor_startPlayback(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return -1;
        }

        oboe::Result result = processor->startPlayback();
        return static_cast<jint>(result);
    }

    /**
     * Stop playback
     * Java: public static native int stopPlayback(long processorHandle);
     */
    JNIEXPORT jint JNICALL
    Java_com_virtualcable_audio_OboeProcessor_stopPlayback(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return -1;
        }

        oboe::Result result = processor->stopPlayback();
        return static_cast<jint>(result);
    }

    /**
     * Write audio data (16-bit PCM)
     * Java: public static native void writeAudioData(long processorHandle, short[] data, int numFrames);
     */
    JNIEXPORT void JNICALL
    Java_com_virtualcable_audio_OboeProcessor_writeAudioData(
        JNIEnv* env, jclass clazz,
        jlong processor_handle, jshortArray data, jint num_frames) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return;
        }

        jshort* data_ptr = env->GetShortArrayElements(data, nullptr);
        if (data_ptr) {
            processor->writeAudioDataPCM16(
                reinterpret_cast<const int16_t*>(data_ptr), num_frames);
            env->ReleaseShortArrayElements(data, data_ptr, JNI_ABORT);
        }
    }

    /**
     * Get available frames in buffer
     * Java: public static native int getAvailableFrames(long processorHandle);
     */
    JNIEXPORT jint JNICALL
    Java_com_virtualcable_audio_OboeProcessor_getAvailableFrames(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return 0;
        }

        return processor->getAvailableFrames();
    }

    /**
     * Get latency in milliseconds
     * Java: public static native int getLatencyMs(long processorHandle);
     */
    JNIEXPORT jint JNICALL
    Java_com_virtualcable_audio_OboeProcessor_getLatencyMs(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return 0;
        }

        return processor->getLatencyMs();
    }

    /**
     * Check if playing
     * Java: public static native boolean isPlaying(long processorHandle);
     */
    JNIEXPORT jboolean JNICALL
    Java_com_virtualcable_audio_OboeProcessor_isPlaying(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return JNI_FALSE;
        }

        return processor->isPlaying() ? JNI_TRUE : JNI_FALSE;
    }

    /**
     * Clear buffer
     * Java: public static native void clearBuffer(long processorHandle);
     */
    JNIEXPORT void JNICALL
    Java_com_virtualcable_audio_OboeProcessor_clearBuffer(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (!processor) {
            LOGE("Invalid processor handle");
            return;
        }

        processor->clearBuffer();
    }

    /**
     * Destroy processor and free resources
     * Java: public static native void destroyProcessor(long processorHandle);
     */
    JNIEXPORT void JNICALL
    Java_com_virtualcable_audio_OboeProcessor_destroyProcessor(
        JNIEnv* env, jclass clazz, jlong processor_handle) {

        OboeProcessor* processor = reinterpret_cast<OboeProcessor*>(processor_handle);
        if (processor) {
            processor->stopPlayback();
            delete processor;
            LOGI("Processor destroyed");
        }
    }
}

# 🚀 Push to GitHub & Build APK

This project is ready to be pushed to GitHub. GitHub Actions will automatically build the APK for you.

## Quick Setup (5 minutes)

### Step 1: Create GitHub Repository

1. Go to https://github.com/new
2. Enter repository name: `virtual-audio-cable`
3. Choose **Public** (so you can access the APK)
4. Click **"Create repository"**

### Step 2: Push Code to GitHub

Copy and paste these commands in your terminal:

```bash
cd /path/to/VirtualAudioCable

git remote add origin https://github.com/YOUR_USERNAME/virtual-audio-cable.git
git branch -M main
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username.

### Step 3: Wait for Build

1. Go to your GitHub repository
2. Click **"Actions"** tab
3. Watch the build progress
4. Wait ~10-15 minutes for completion

### Step 4: Download APK

When build is complete:

1. Go to **"Actions"** → **"Build APK"** (latest run)
2. Scroll down to **"Artifacts"**
3. Download **"virtual-audio-cable-debug"** or **"virtual-audio-cable-release"**
4. Extract the APK file
5. Install on your Blu G63!

---

## 📱 Install on Blu G63

1. Download APK from GitHub Actions
2. Transfer to your phone (email, cloud, USB, etc.)
3. Open Files app → Downloads
4. Tap APK file → Install
5. Grant permissions
6. Done! 🎉

---

## 🔄 Automatic Builds

Every time you push code, GitHub Actions automatically:
- ✅ Downloads Android SDK
- ✅ Clones Oboe library
- ✅ Builds Debug APK
- ✅ Builds Release APK
- ✅ Uploads to Artifacts

---

## ⚠️ Important Notes

- **Public Repository:** APK is publicly downloadable (that's fine!)
- **Build Time:** First build takes ~15 minutes, subsequent builds ~10 minutes
- **Free:** GitHub Actions is free for public repositories
- **Storage:** APKs are stored for 90 days in Artifacts

---

## 🆘 Troubleshooting

### "Build failed" in GitHub Actions
- Check the build logs in Actions tab
- Most common: NDK or SDK download issues (usually resolves on retry)
- Click **"Re-run jobs"** to try again

### Can't find Artifacts
- Build must complete successfully first
- Check Actions tab → latest "Build APK" workflow
- Scroll to bottom for Artifacts section

### APK won't install on phone
- Ensure Android 10 or higher
- Enable "Unknown Sources" in Settings
- Try Debug APK first (easier to install)

---

## 📞 Need Help?

1. Check GitHub Actions logs for error details
2. Ensure repository is public
3. Verify git push was successful

---

**That's it! Your APK will be ready in GitHub Actions.** 🚀

# Virtual Audio Cable for Android: Technical Research & Architecture

## 1. Technical Feasibility Analysis
### Audio Capture (The Listener)
*   **API:** `AudioPlaybackCaptureConfig` (Android 10+, API 29).
*   **Mechanism:** Requires `MediaProjection` token. The user must manually grant permission via a system dialog.
*   **Constraint:** Only captures audio from apps that allow it (most media apps like SoundCloud/YouTube do, but some may opt-out via `android:allowAudioPlaybackCapture="false"`).

### Low Latency Processing (The Pipe)
*   **Library:** Google **Oboe** (C++).
*   **Reasoning:** Oboe automatically selects between AAudio (Android 8.1+) and OpenSL ES (older), providing the lowest possible latency.
*   **Implementation:** PCM data from `AudioRecord` (capture) is pushed into an Oboe callback for real-time processing/buffering.

### Virtual Mic Injection (The Injector) - The Core Challenge
*   **Standard SDK:** Android does **not** provide a public API to create a "Virtual Microphone" that other apps can select.
*   **Workaround (Loopback):** 
    1.  **AAudio/Oboe Loopback:** While we can capture and play back to the *speaker*, we cannot natively "inject" into the `VOICE_COMMUNICATION` or `MIC` input of another app without root or system-level signatures.
    2.  **External Hardware Loopback (Reference):** Some "Virtual Mic" apps on Play Store actually use a physical TRRS loopback cable or a specific USB interface.
    3.  **Software Simulation (The "Senior Developer" approach):** 
        *   We can use a **Foreground Service** to maintain the capture.
        *   To "inject" into a game, the most viable non-root method is to use **AAudio** to write to the system's output stream and hope the destination app's "Acoustic Echo Cancellation" (AEC) or specific routing allows it. 
        *   **Alternative:** If the target game uses a specific audio engine, we might be able to influence the routing, but for general apps, a true "Virtual Mic" requires a **custom Audio HAL** (Root only).
        *   **Proposed Non-Root Strategy:** Use `AudioTrack` with `USAGE_VOICE_COMMUNICATION` and try to route the captured internal audio into the telephony/comm stream.

### Samsung Specifics
*   **Separate App Sound:** Samsung's API allows routing specific apps to specific outputs (e.g., Bluetooth vs Speaker). We can leverage this to isolate the "Source App" (SoundCloud) from the "Destination App" (Game).
*   **Samsung Knox/SDK:** Check for `AudioRoute` or `SAMSUNG_AUDIO_ROUTING` APIs which are more flexible than standard Android.

## 2. Proposed Component Architecture
1.  **MediaProjectionService:** Handles the screen capture token and lifecycle.
2.  **AudioCaptureEngine (Kotlin/JNI):** Uses `AudioRecord` with `AudioPlaybackCaptureConfig`.
3.  **OboeProcessor (C++):** A circular buffer and resampling engine to sync capture with injection.
4.  **InjectionEngine:** Manages the "output" side, attempting to feed the data back into the system's input stream.
5.  **UI Dashboard:** Jetpack Compose based, showing real-time visualizer.

## 3. Implementation Plan
1.  Initialize Project with Oboe dependency.
2.  Implement `MediaProjection` request flow.
3.  Build the `AudioPlaybackCapture` logic.
4.  Develop the Oboe C++ wrapper for buffering.
5.  Create the Foreground Service to tie them together.

# Virtual Audio Cable for Android - Complete Implementation Guide

## Table of Contents
1. [Project Overview](#project-overview)
2. [Technical Architecture](#technical-architecture)
3. [Component Breakdown](#component-breakdown)
4. [Setup Instructions](#setup-instructions)
5. [Building & Deployment](#building--deployment)
6. [Testing Guide](#testing-guide)
7. [Troubleshooting](#troubleshooting)
8. [Performance Optimization](#performance-optimization)

---

## Project Overview

**Virtual Audio Cable** is an Android application that captures internal system audio from apps (SoundCloud, YouTube) and reroutes it as a virtual microphone input for other applications (games like Flex City, Oxide).

### Key Features
- **Real-time Audio Capture:** Uses `AudioPlaybackCaptureConfig` (Android 10+) to capture internal system audio
- **Low-Latency Processing:** Leverages Google's Oboe library for minimal audio delay
- **Virtual Microphone Injection:** Attempts to route captured audio into the system's microphone input stream
- **Modern Dashboard UI:** Jetpack Compose-based interface with real-time audio visualizer
- **Samsung Optimization:** Special handling for Samsung Galaxy devices
- **Cross-Device Support:** Works on any Android 10+ device (Samsung, Blu, etc.)

### Target Devices
- Samsung Galaxy G63 (and other Galaxy models)
- Blu G63 G0870 (and other Blu devices)
- Any Android 10+ device with AudioPlaybackCaptureConfig support

---

## Technical Architecture

### High-Level Flow

```
Source App (SoundCloud)
        ↓
AudioPlaybackCaptureConfig (MediaProjection)
        ↓
AudioCaptureEngine (AudioRecord)
        ↓
OboeProcessor (C++ Circular Buffer)
        ↓
InjectionEngine (AudioTrack)
        ↓
Destination App (Game)
```

### Component Stack

| Component | Language | Purpose | Key Dependency |
|-----------|----------|---------|-----------------|
| **AudioCaptureEngine** | Kotlin | Captures internal audio via AudioRecord | Android Media Framework |
| **OboeProcessor** | C++ (JNI) | Low-latency buffering and processing | Google Oboe Library |
| **InjectionEngine** | Kotlin | Attempts to inject audio into mic input | Android AudioTrack |
| **AudioCableService** | Kotlin | Foreground service orchestrating all components | Android Service Framework |
| **DashboardScreen** | Kotlin (Compose) | UI with visualizer and controls | Jetpack Compose |
| **SamsungAudioOptimizer** | Kotlin | Device-specific optimizations | Samsung APIs (optional) |
| **PermissionsManager** | Kotlin | Handles all permission requests | Android Permissions Framework |

---

## Component Breakdown

### 1. AudioCaptureEngine.kt
**Responsibility:** Capture internal system audio using AudioPlaybackCaptureConfig

**Key Methods:**
```kotlin
fun start(onAudioData: (ByteArray, Int) -> Unit, onError: ((String) -> Unit)? = null)
fun stop()
fun getStatistics(): CaptureStatistics
```

**How It Works:**
1. Receives `MediaProjection` token from user permission
2. Creates `AudioPlaybackCaptureConfiguration` to capture system audio
3. Initializes `AudioRecord` with the capture config
4. Runs background thread that continuously reads PCM data
5. Invokes callback with raw audio bytes

**Audio Format:**
- Sample Rate: 48000 Hz
- Channels: Mono (1 channel)
- Encoding: PCM 16-bit

### 2. OboeProcessor.cpp & OboeProcessor.kt
**Responsibility:** Low-latency audio processing and buffering

**Key Features:**
- Circular buffer for PCM data storage
- AAudio backend with OpenSL ES fallback
- Real-time audio callback
- Sample rate conversion support
- Minimal latency configuration

**JNI Methods:**
```cpp
long createProcessor(int sampleRate, int channelCount);
int startPlayback(long processorHandle);
int stopPlayback(long processorHandle);
void writeAudioData(long processorHandle, short[] data, int numFrames);
int getAvailableFrames(long processorHandle);
int getLatencyMs(long processorHandle);
```

**Latency Optimization:**
- Uses `PerformanceMode::LowLatency`
- Requests `SharingMode::Exclusive` for dedicated audio stream
- Minimizes buffer sizes
- Processes audio in callback (not on main thread)

### 3. InjectionEngine.kt
**Responsibility:** Inject captured audio into system's microphone input

**Injection Modes:**
1. **VOICE_COMMUNICATION:** Primary mode - uses `USAGE_VOICE_COMMUNICATION` to route to telephony/comm stream
2. **SPEAKER_LOOPBACK:** Fallback - writes to speaker output (acoustic loopback)
3. **MUSIC_PLAYBACK:** Alternative - uses `USAGE_MEDIA` for music routing

**Limitation Note:**
Android does not provide a public API to directly inject into the microphone input without root or system-level signatures. This implementation uses the best available workaround via `AudioTrack` with voice communication usage.

### 4. AudioCableService.kt
**Responsibility:** Orchestrate all components and manage lifecycle

**Service Actions:**
- `ACTION_START_CAPTURE` - Begin audio capture
- `ACTION_STOP_CAPTURE` - Stop audio capture
- `ACTION_START_INJECTION` - Begin audio injection
- `ACTION_STOP_INJECTION` - Stop audio injection

**Broadcasts:**
- `BROADCAST_STATUS_CHANGED` - Status update for UI
- `BROADCAST_AUDIO_LEVELS` - Real-time audio levels for visualizer
- `BROADCAST_ERROR` - Error notifications

**Foreground Notification:**
Shows persistent notification with current status (Capturing, Injecting, etc.)

### 5. DashboardScreen.kt
**Responsibility:** Modern UI with real-time audio visualizer

**UI Components:**
- **AudioVisualizerBars:** 16-bar real-time level display
- **AudioStatusCard:** Shows capture/injection status and latency
- **AppSelector:** Dropdown for source and destination app selection
- **ControlButton:** Start/Stop buttons for capture and injection
- **InfoSection:** Tips and usage instructions

### 6. SamsungAudioOptimizer.kt
**Responsibility:** Samsung-specific optimizations

**Features:**
- Device detection (Samsung brand check)
- Model identification (Galaxy G63, etc.)
- Separate App Sound capability detection
- Samsung-specific audio routing APIs
- Gaming optimization flags

### 7. PermissionsManager.kt
**Responsibility:** Handle all permission requests

**Required Permissions:**
- `RECORD_AUDIO` - For AudioRecord
- `FOREGROUND_SERVICE` - For background service (Android 12+)
- `MODIFY_AUDIO_SETTINGS` - For audio routing
- `MEDIA_CONTENT_CONTROL` - For media control
- `QUERY_ALL_PACKAGES` - To list installed apps (Android 11+)

---

## Setup Instructions

### Prerequisites
- Android Studio Giraffe (2022.3.1) or later
- Android SDK 34 (API level 34)
- NDK r25 or later (for C++ compilation)
- Kotlin 1.9.0 or later
- Gradle 8.1.0 or later

### Step 1: Clone/Create Project Structure

```bash
mkdir VirtualAudioCable
cd VirtualAudioCable

# Create directory structure
mkdir -p app/src/main/cpp
mkdir -p app/src/main/java/com/virtualcable
mkdir -p app/src/main/res
```

### Step 2: Add Oboe Library

```bash
cd app/src/main/cpp

# Clone Oboe library
git clone https://github.com/google/oboe.git

# Verify Oboe structure
ls oboe/include/oboe/  # Should contain Oboe.h and other headers
```

### Step 3: Create Gradle Files

**settings.gradle.kts:**
```kotlin
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "VirtualAudioCable"
include(":app")
```

### Step 4: Copy Source Files

Copy all Kotlin files to `app/src/main/java/com/virtualcable/`:
- `AudioCaptureEngine.kt`
- `MediaProjectionManager.kt`
- `OboeProcessor.kt`
- `InjectionEngine.kt`
- `AudioCableService.kt`
- `DashboardScreen.kt` (and other UI components)
- `SamsungAudioOptimizer.kt`
- `PermissionsManager.kt`

Copy C++ files to `app/src/main/cpp/`:
- `oboe_processor.cpp`
- `CMakeLists.txt`

### Step 5: Create Resource Files

**res/values/strings.xml:**
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Virtual Audio Cable</string>
    <string name="capture_label">Start Capturing</string>
    <string name="injection_label">Start Injecting</string>
</resources>
```

**res/values/themes.xml:**
```xml
<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.VirtualAudioCable" parent="android:Theme.Material.Light">
        <item name="android:colorPrimary">@color/primary</item>
    </style>
</resources>
```

---

## Building & Deployment

### Build APK

```bash
# Debug build
./gradlew assembleDebug

# Release build (requires signing key)
./gradlew assembleRelease
```

### Generated APK Location
```
app/build/outputs/apk/debug/app-debug.apk
app/build/outputs/apk/release/app-release.apk
```

### Install on Device

```bash
# Via ADB
adb install app/build/outputs/apk/debug/app-debug.apk

# Or drag-drop APK to device file manager
```

---

## Testing Guide

### Unit Tests

**Test AudioCaptureEngine:**
```kotlin
@Test
fun testAudioCaptureStart() {
    val engine = AudioCaptureEngine(mockMediaProjection)
    engine.start { data, size ->
        Assert.assertTrue(size > 0)
    }
    Assert.assertTrue(engine.isRunning())
}
```

**Test OboeProcessor:**
```kotlin
@Test
fun testOboeProcessorCreation() {
    val processor = OboeProcessor(48000, 1)
    Assert.assertTrue(processor.getStatistics().isInitialized)
}
```

### Integration Tests

1. **Permission Flow:**
   - Launch app
   - Verify permission request dialog
   - Grant all permissions
   - Verify permissions accepted

2. **Capture Flow:**
   - Play audio in SoundCloud/YouTube
   - Click "Start Capturing"
   - Verify visualizer shows audio levels
   - Verify statistics update

3. **Injection Flow:**
   - Start capture
   - Click "Start Injecting"
   - Open game (Flex City/Oxide)
   - Verify game receives audio as microphone input

### Manual Testing Checklist

- [ ] App launches without crashes
- [ ] Permission request works
- [ ] Audio visualizer updates in real-time
- [ ] Capture starts/stops correctly
- [ ] Injection starts/stops correctly
- [ ] Latency is acceptable (<50ms)
- [ ] Works on Samsung Galaxy G63
- [ ] Works on Blu G63 G0870
- [ ] Works on other Android 10+ devices
- [ ] Foreground notification shows correct status
- [ ] No memory leaks after 1 hour of use

---

## Troubleshooting

### Issue: "AudioRecord failed to initialize"
**Cause:** MediaProjection not granted or invalid
**Solution:**
1. Ensure MediaProjection permission dialog was shown
2. User must grant permission
3. Restart app and try again

### Issue: "Oboe library not found"
**Cause:** Native library not compiled
**Solution:**
1. Verify NDK is installed
2. Check `CMakeLists.txt` syntax
3. Run: `./gradlew clean && ./gradlew build`

### Issue: Audio latency is too high (>100ms)
**Cause:** Buffer sizes too large or device not optimized
**Solution:**
1. Reduce buffer multiplier in `SamsungAudioOptimizer`
2. Use exclusive mode in Oboe
3. Ensure no other apps using audio
4. Test on different device

### Issue: Audio not reaching destination app
**Cause:** Injection mode not working on this device
**Solution:**
1. Try different injection modes (VOICE_COMMUNICATION, SPEAKER_LOOPBACK)
2. Check if destination app accepts microphone input
3. Test with different games/apps
4. Check Android version compatibility

### Issue: "Permission denied" errors
**Cause:** Permissions not granted
**Solution:**
1. Go to Settings → Apps → Virtual Audio Cable → Permissions
2. Enable all required permissions
3. Restart app

---

## Performance Optimization

### Audio Latency Optimization

**Capture Latency:**
- Use minimum buffer size multiplier
- Run capture on dedicated thread
- Avoid UI updates in capture callback

**Processing Latency:**
- Oboe handles this automatically
- Use exclusive mode when possible
- Minimize sample rate conversion

**Injection Latency:**
- Use VOICE_COMMUNICATION usage
- Queue audio data efficiently
- Monitor buffer levels

### Memory Optimization

**Circular Buffer:**
- Size: 2 seconds of audio (48000 * 2 * 2 bytes = 192KB)
- Reuse buffers instead of allocating new ones
- Clear buffers when stopping

**Thread Management:**
- Use thread pools for background tasks
- Properly join threads on shutdown
- Avoid creating threads in callbacks

### CPU Optimization

**Oboe Processing:**
- Runs in real-time callback thread
- Minimal CPU overhead
- AAudio backend is more efficient than OpenSL ES

**UI Updates:**
- Throttle visualizer updates to 30 FPS
- Use LiveData for state management
- Avoid recomposition on every frame

---

## Advanced Configuration

### Custom Audio Parameters

**Modify in AudioCaptureEngine.kt:**
```kotlin
AudioCaptureEngine(
    mediaProjection = mediaProjection,
    sampleRate = 48000,      // Can be 44100, 48000, etc.
    channelConfig = AudioFormat.CHANNEL_IN_MONO,  // Or STEREO
    audioFormat = AudioFormat.ENCODING_PCM_16BIT   // Or PCM_FLOAT
)
```

### Samsung-Specific Tuning

**In SamsungAudioOptimizer.kt:**
```kotlin
config.apply {
    sampleRate = 48000
    bufferMultiplier = 3      // Increase for stability
    useExclusiveMode = true
    useVoiceCommunication = true
}
```

### Injection Mode Selection

**In InjectionEngine.kt:**
```kotlin
injectionEngine?.start(
    mode = InjectionEngine.Companion.InjectionMode.VOICE_COMMUNICATION
    // Or: SPEAKER_LOOPBACK, MUSIC_PLAYBACK
)
```

---

## References & Resources

- [Android AudioPlaybackCapture API](https://developer.android.com/reference/android/media/AudioPlaybackCaptureConfiguration)
- [Google Oboe Library](https://github.com/google/oboe)
- [Android Audio Architecture](https://developer.android.com/guide/topics/media-apps/audio-app)
- [Jetpack Compose Documentation](https://developer.android.com/jetpack/compose)
- [Android NDK Guide](https://developer.android.com/ndk)

---

## License

This project is provided as-is for educational and development purposes.

---

## Support & Contribution

For issues, feature requests, or contributions, please refer to the project repository.

**Last Updated:** February 2026
**Version:** 1.0.0

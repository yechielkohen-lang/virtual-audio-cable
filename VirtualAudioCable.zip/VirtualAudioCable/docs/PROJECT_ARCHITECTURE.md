# Virtual Audio Cable Android - Project Architecture

## 1. High-Level Architecture Overview

```
┌─────────────────────────────────────────────────────────────┐
│                    Virtual Audio Cable App                   │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  UI Layer (Jetpack Compose)                          │   │
│  │  - Dashboard with visualizer                         │   │
│  │  - App selector (Source/Destination)                 │   │
│  │  - Start/Stop button & status indicator              │   │
│  └──────────────────────────────────────────────────────┘   │
│                           ▼                                   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Service Layer (Foreground Service)                  │   │
│  │  - MediaProjection lifecycle management              │   │
│  │  - Permission handling & notification                │   │
│  └──────────────────────────────────────────────────────┘   │
│                           ▼                                   │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Audio Engine (Kotlin + JNI)                         │   │
│  │  ┌──────────────────────────────────────────────┐   │   │
│  │  │ AudioCaptureEngine (Kotlin)                  │   │   │
│  │  │ - AudioRecord with AudioPlaybackCaptureConfig│   │   │
│  │  │ - Reads PCM data in real-time                │   │   │
│  │  └──────────────────────────────────────────────┘   │   │
│  │                      ▼                               │   │
│  │  ┌──────────────────────────────────────────────┐   │   │
│  │  │ OboeProcessor (C++ via JNI)                  │   │   │
│  │  │ - Circular buffer for PCM data               │   │   │
│  │  │ - Sample rate conversion (if needed)         │   │   │
│  │  │ - Low-latency AAudio stream                  │   │   │
│  │  └──────────────────────────────────────────────┘   │   │
│  │                      ▼                               │   │
│  │  ┌──────────────────────────────────────────────┐   │   │
│  │  │ InjectionEngine (Kotlin + AAudio)            │   │   │
│  │  │ - AudioTrack with VOICE_COMMUNICATION usage  │   │   │
│  │  │ - Attempts to route to mic input             │   │   │
│  │  │ - Fallback: write to speaker (loopback)      │   │   │
│  │  └──────────────────────────────────────────────┘   │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

## 2. Module Breakdown

### 2.1 UI Layer (Jetpack Compose)
**File:** `MainActivity.kt`, `ui/screens/DashboardScreen.kt`

- **DashboardScreen:** Main UI with:
  - Real-time audio level visualizer (waveform or frequency bars)
  - Source app selector (dropdown with installed media apps)
  - Destination app selector (dropdown with games/apps)
  - Start/Stop toggle button
  - Status indicator (Connected/Disconnected/Error)
  - Settings button (opens Samsung-specific options)

- **Visualizer Component:** Custom Canvas-based component that renders:
  - Audio level bars (dB scale)
  - Waveform or frequency spectrum
  - Real-time updates via callback from audio engine

### 2.2 Service Layer (AudioCableService)
**File:** `services/AudioCableService.kt`

- **Responsibilities:**
  - Manages `MediaProjection` lifecycle (request → grant → release)
  - Runs as a Foreground Service to keep audio capture alive
  - Handles permission requests and callbacks
  - Manages lifecycle of AudioCaptureEngine and OboeProcessor
  - Broadcasts status updates to UI

- **Permissions Handled:**
  - `RECORD_AUDIO`
  - `FOREGROUND_SERVICE`
  - `MODIFY_AUDIO_SETTINGS`
  - `MEDIA_CONTENT_CONTROL`

### 2.3 Audio Capture Engine (Kotlin)
**File:** `audio/AudioCaptureEngine.kt`

**Key Class:**
```kotlin
class AudioCaptureEngine(
    private val mediaProjection: MediaProjection,
    private val sampleRate: Int = 48000,
    private val channelConfig: Int = AudioFormat.CHANNEL_IN_MONO,
    private val audioFormat: Int = AudioFormat.ENCODING_PCM_16BIT
) {
    private lateinit var audioRecord: AudioRecord
    private var captureThread: Thread? = null
    private var isCapturing = false
    
    fun start(onAudioDataCallback: (ByteArray) -> Unit) { }
    fun stop() { }
    private fun captureLoop(callback: (ByteArray) -> Unit) { }
}
```

**Flow:**
1. Create `AudioPlaybackCaptureConfig` with `mediaProjection`
2. Initialize `AudioRecord` with the config
3. Start capture thread that continuously reads PCM data
4. Invoke callback with raw PCM bytes
5. Callback feeds data to OboeProcessor

### 2.4 Oboe Processor (C++ via JNI)
**Files:** `cpp/oboe_processor.cpp`, `cpp/oboe_processor.h`

**Key Responsibilities:**
- Manages a circular buffer for PCM data
- Provides low-latency AAudio stream for playback
- Handles sample rate conversion (e.g., 44.1kHz → 48kHz)
- Implements the audio callback for real-time processing

**Pseudo-Code:**
```cpp
class OboeProcessor {
public:
    OboeProcessor(int sampleRate, int channelCount);
    ~OboeProcessor();
    
    void writeAudioData(const float* data, int numFrames);
    void startPlayback();
    void stopPlayback();
    
private:
    std::shared_ptr<oboe::AudioStream> stream_;
    CircularBuffer<float> buffer_;
    oboe::DataCallbackResult onAudioReady(
        oboe::AudioStream* stream,
        void* audioData,
        int32_t numFrames
    );
};
```

### 2.5 Injection Engine (Kotlin + AAudio)
**File:** `audio/InjectionEngine.kt`

**Strategy:**
- Use `AudioTrack` with `USAGE_VOICE_COMMUNICATION` to attempt routing to mic input
- Fallback: Write to speaker output (acoustic loopback)
- Monitor system audio routing for Samsung-specific APIs

**Key Class:**
```kotlin
class InjectionEngine(
    private val sampleRate: Int = 48000,
    private val channelConfig: Int = AudioFormat.CHANNEL_OUT_MONO
) {
    private lateinit var audioTrack: AudioTrack
    
    fun start() { }
    fun writeAudio(audioData: ByteArray) { }
    fun stop() { }
    fun getLatency(): Long { }
}
```

### 2.6 Samsung-Specific Optimization Module
**File:** `samsung/SamsungAudioOptimizer.kt`

**Features:**
- Detect Samsung device and API level
- Query "Separate App Sound" capability
- Route source app audio to isolated stream
- Use Samsung's `AudioRoute` API if available
- Optimize for Galaxy G63 specifically

**Pseudo-Code:**
```kotlin
object SamsungAudioOptimizer {
    fun isSamsungDevice(): Boolean { }
    fun enableSeparateAppSound(sourceApp: String): Boolean { }
    fun getOptimalAudioRoute(): AudioRoute { }
    fun applySamsungOptimizations(engine: AudioCaptureEngine) { }
}
```

## 3. Data Flow

### Audio Capture → Processing → Injection

```
┌──────────────────┐
│ Source App       │
│ (SoundCloud)     │
└────────┬─────────┘
         │ Internal Audio Stream
         ▼
┌──────────────────────────────────────┐
│ AudioPlaybackCaptureConfig           │
│ (Captures via MediaProjection)       │
└────────┬─────────────────────────────┘
         │ PCM Data (16-bit, 48kHz)
         ▼
┌──────────────────────────────────────┐
│ AudioRecord (Capture Thread)         │
│ Reads in chunks (e.g., 4096 frames)  │
└────────┬─────────────────────────────┘
         │ Raw PCM Bytes
         ▼
┌──────────────────────────────────────┐
│ OboeProcessor (C++ Circular Buffer)  │
│ - Stores PCM data                    │
│ - Handles sample rate conversion     │
│ - Provides low-latency stream        │
└────────┬─────────────────────────────┘
         │ Processed PCM
         ▼
┌──────────────────────────────────────┐
│ InjectionEngine (AudioTrack)         │
│ - USAGE_VOICE_COMMUNICATION          │
│ - Attempts mic input routing         │
└────────┬─────────────────────────────┘
         │ Audio Output
         ▼
┌──────────────────┐
│ Destination App  │
│ (Game)           │
│ Sees as Mic Input│
└──────────────────┘
```

## 4. Threading Model

| Thread | Purpose | Lifecycle |
|--------|---------|-----------|
| **Main Thread** | UI updates, user interactions | App lifetime |
| **Capture Thread** | AudioRecord.read() loop | Service running |
| **Oboe Callback Thread** | Real-time audio processing | AudioStream active |
| **Injection Thread** | AudioTrack.write() loop | Service running |

**Synchronization:**
- Use `AtomicBoolean` for thread-safe flags
- `BlockingQueue` for PCM data between capture and processing
- Oboe handles its own internal threading

## 5. Permissions & Manifest Entries

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />
<uses-permission android:name="android.permission.MEDIA_CONTENT_CONTROL" />
<uses-permission android:name="android.permission.QUERY_ALL_PACKAGES" />

<service
    android:name=".services.AudioCableService"
    android:foregroundServiceType="mediaProjection"
    android:enabled="true"
    android:exported="false" />
```

## 6. Key Challenges & Solutions

| Challenge | Solution |
|-----------|----------|
| **Virtual Mic Injection (No Direct API)** | Use AudioTrack with VOICE_COMMUNICATION usage + Samsung Separate App Sound API |
| **Low Latency** | Oboe library + AAudio + exclusive mode + minimal buffer sizes |
| **MediaProjection Permission** | User must grant via system dialog; handle gracefully with retry |
| **Samsung Compatibility** | Detect device, apply Samsung-specific audio routing APIs |
| **Foreground Service Notification** | Show persistent notification with app name and status |
| **Sample Rate Mismatch** | Implement resampling in Oboe processor (e.g., 44.1kHz → 48kHz) |

## 7. Build Configuration

**build.gradle.kts (App Module):**
```kotlin
android {
    compileSdk = 34
    minSdk = 29  // Android 10 (AudioPlaybackCaptureConfig requirement)
    targetSdk = 34
    
    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
        }
    }
}

dependencies {
    // Oboe
    implementation("com.google.oboe:oboe:1.10.0")
    
    // Jetpack Compose
    implementation("androidx.compose.ui:ui:1.6.0")
    implementation("androidx.compose.material3:material3:1.1.0")
    
    // Media
    implementation("androidx.media:media:1.6.0")
    
    // Coroutines
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.1")
}
```

**CMakeLists.txt (Oboe Integration):**
```cmake
cmake_minimum_required(VERSION 3.18.1)
project(VirtualAudioCable)

add_subdirectory(oboe)

add_library(oboe_processor SHARED
    oboe_processor.cpp
)

target_link_libraries(oboe_processor
    oboe
    log
    OpenSLES
)
```

## 8. Testing Strategy

1. **Unit Tests:** Test AudioCaptureEngine and InjectionEngine in isolation
2. **Integration Tests:** Test full capture → process → inject flow
3. **Device Tests:** Test on Samsung Galaxy G63 and other devices
4. **Latency Profiling:** Measure end-to-end latency with test app
5. **Permission Tests:** Verify all permission flows work correctly

## 9. Future Enhancements

- [ ] Support for stereo audio capture
- [ ] Real-time audio effects (EQ, compression)
- [ ] Multi-app source mixing
- [ ] Bluetooth audio routing
- [ ] Recording to file for debugging
- [ ] Advanced visualizer (spectrum analyzer)
- [ ] Preset configurations for popular games

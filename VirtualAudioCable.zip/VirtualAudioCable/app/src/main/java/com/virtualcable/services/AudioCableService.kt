package com.virtualcable.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.MediaProjection\nimport android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.core.app.NotificationCompat
import com.virtualcable.audio.AudioCaptureEngine
import com.virtualcable.audio.InjectionEngine
import com.virtualcable.audio.OboeProcessor
import com.virtualcable.samsung.SamsungAudioOptimizer
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread

/**
 * AudioCableService: Main foreground service for Virtual Audio Cable
 *
 * Responsibilities:
 * - Manages MediaProjection lifecycle
 * - Orchestrates AudioCaptureEngine, OboeProcessor, and InjectionEngine
 * - Maintains foreground notification
 * - Handles service lifecycle and cleanup
 * - Broadcasts status updates to UI
 */
@RequiresApi(Build.VERSION_CODES.Q)  // Android 10+
class AudioCableService : Service() {
    companion object {
        private const val TAG = "AudioCableService"
        private const val NOTIFICATION_ID = 1001
        private const val NOTIFICATION_CHANNEL_ID = "audio_cable_channel"

        // Intent actions
        const val ACTION_START_CAPTURE = "com.virtualcable.START_CAPTURE"
        const val ACTION_STOP_CAPTURE = "com.virtualcable.STOP_CAPTURE"
        const val ACTION_START_INJECTION = "com.virtualcable.START_INJECTION"
        const val ACTION_STOP_INJECTION = "com.virtualcable.STOP_INJECTION"

        // Broadcast actions
        const val BROADCAST_STATUS_CHANGED = "com.virtualcable.STATUS_CHANGED"
        const val BROADCAST_AUDIO_LEVELS = "com.virtualcable.AUDIO_LEVELS"
        const val BROADCAST_ERROR = "com.virtualcable.ERROR"

        // Extra keys
        const val EXTRA_IS_CAPTURING = "is_capturing"
        const val EXTRA_IS_INJECTING = "is_injecting"
        const val EXTRA_AUDIO_LEVELS = "audio_levels"
        const val EXTRA_ERROR_MESSAGE = "error_message"
    }

    // Service components
    private var mediaProjection: MediaProjection? = null
    private var audioCaptureEngine: AudioCaptureEngine? = null
    private var oboeProcessor: OboeProcessor? = null
    private var injectionEngine: InjectionEngine? = null
    private var samsungOptimizer: SamsungAudioOptimizer? = null

    // State management
    private val isCapturing = AtomicBoolean(false)
    private val isInjecting = AtomicBoolean(false)

    // Binder for client communication
    private val binder = LocalBinder()

    // Audio data buffer
    private val audioBuffer = ByteArray(4096)

    /**
     * Local binder for service communication
     */
    inner class LocalBinder : Binder() {
        fun getService(): AudioCableService = this@AudioCableService
    }

    /**
     * Service creation
     */
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "Service created")

        // Initialize Samsung optimizer
        samsungOptimizer = SamsungAudioOptimizer(this)
        Log.d(TAG, samsungOptimizer?.getDeviceInfo() ?: "Unknown device")

        // Create notification channel
        createNotificationChannel()
    }

    /**
     * Service start
     */
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "onStartCommand: action=${intent?.action}")

        when (intent?.action) {
            ACTION_START_CAPTURE -> startCapture(intent)
            ACTION_STOP_CAPTURE -> stopCapture()
            ACTION_START_INJECTION -> startInjection()
            ACTION_STOP_INJECTION -> stopInjection()
        }

        return START_STICKY
    }

    /**
     * Bind to service
     */
    override fun onBind(intent: Intent?): IBinder {
        Log.d(TAG, "Service bound")
        return binder
    }

    /**
     * Service destruction
     */
    override fun onDestroy() {
        Log.i(TAG, "Service destroyed")
        stopCapture()
        stopInjection()
        releaseMediaProjection()
        super.onDestroy()
    }

    /**
     * Start audio capture
     */
    private fun startCapture(intent: Intent?) {
        if (isCapturing.get()) {
            Log.w(TAG, "Capture already running")
            return
        }

        try {
            // Get MediaProjection from intent
            mediaProjection = intent?.let { extractMediaProjection(it) }
            if (mediaProjection == null) {
                broadcastError("Failed to get MediaProjection")
                return
            }

            Log.d(TAG, "Starting audio capture")

            // Initialize audio capture engine
            audioCaptureEngine = AudioCaptureEngine(
                mediaProjection = mediaProjection!!,
                sampleRate = 48000,
                channelConfig = android.media.AudioFormat.CHANNEL_IN_MONO,
                audioFormat = android.media.AudioFormat.ENCODING_PCM_16BIT
            )

            // Initialize Oboe processor
            oboeProcessor = OboeProcessor(
                sampleRate = 48000,
                channelCount = 1
            )

            // Start capture with callback
            audioCaptureEngine?.start(
                onAudioData = { data, numBytes ->
                    onAudioDataCaptured(data, numBytes)
                },
                onError = { error ->
                    Log.e(TAG, "Capture error: $error")
                    broadcastError(error)
                }
            )

            isCapturing.set(true)
            updateNotification()
            broadcastStatusChanged()

            Log.i(TAG, "Audio capture started")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting capture", e)
            broadcastError("Failed to start capture: ${e.message}")
        }
    }

    /**
     * Stop audio capture
     */
    private fun stopCapture() {
        if (!isCapturing.getAndSet(false)) {
            Log.w(TAG, "Capture not running")
            return
        }

        try {
            Log.d(TAG, "Stopping audio capture")

            audioCaptureEngine?.stop()
            audioCaptureEngine = null

            updateNotification()
            broadcastStatusChanged()

            Log.i(TAG, "Audio capture stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping capture", e)
        }
    }

    /**
     * Start audio injection
     */
    private fun startInjection() {
        if (isInjecting.get()) {
            Log.w(TAG, "Injection already running")
            return
        }

        try {
            Log.d(TAG, "Starting audio injection")

            // Initialize injection engine
            injectionEngine = InjectionEngine(
                sampleRate = 48000,
                channelConfig = android.media.AudioFormat.CHANNEL_OUT_MONO,
                audioFormat = android.media.AudioFormat.ENCODING_PCM_16BIT
            )

            // Start with voice communication mode
            val started = injectionEngine?.start(
                mode = InjectionEngine.Companion.InjectionMode.VOICE_COMMUNICATION
            ) ?: false

            if (!started) {
                broadcastError("Failed to start injection engine")
                return
            }

            // Start Oboe processor playback
            oboeProcessor?.startPlayback()

            isInjecting.set(true)
            updateNotification()
            broadcastStatusChanged()

            Log.i(TAG, "Audio injection started")
        } catch (e: Exception) {
            Log.e(TAG, "Error starting injection", e)
            broadcastError("Failed to start injection: ${e.message}")
        }
    }

    /**
     * Stop audio injection
     */
    private fun stopInjection() {
        if (!isInjecting.getAndSet(false)) {
            Log.w(TAG, "Injection not running")
            return
        }

        try {
            Log.d(TAG, "Stopping audio injection")

            oboeProcessor?.stopPlayback()
            injectionEngine?.stop()
            injectionEngine = null

            updateNotification()
            broadcastStatusChanged()

            Log.i(TAG, "Audio injection stopped")
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping injection", e)
        }
    }

    /**
     * Handle captured audio data
     */
    private fun onAudioDataCaptured(data: ByteArray, numBytes: Int) {
        try {
            // Write to Oboe processor
            val shortArray = ByteArray(numBytes).apply {
                System.arraycopy(data, 0, this, 0, numBytes)
            }

            // Convert to short array for Oboe
            val frames = numBytes / 2
            oboeProcessor?.writeAudioDataFromBytes(shortArray)

            // Optionally write to injection engine
            if (isInjecting.get()) {
                injectionEngine?.writeAudio(shortArray)
            }

            // Broadcast audio levels for UI visualization
            broadcastAudioLevels(data, numBytes)
        } catch (e: Exception) {
            Log.e(TAG, "Error processing audio data", e)
        }
    }

    /**
     * Extract MediaProjection from intent
     */
    private fun extractMediaProjection(intent: Intent): MediaProjection? {
        return try {
            val projectionManager = getSystemService(MEDIA_PROJECTION_SERVICE) as? android.media.MediaProjectionManager
            val resultCode = intent.getIntExtra("resultCode", -1)
            val resultData = intent.getParcelableExtra<Intent>("resultData")

            if (resultCode != -1 && resultData != null && projectionManager != null) {
                projectionManager.getMediaProjection(resultCode, resultData)
            } else {
                null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error extracting MediaProjection", e)
            null
        }
    }

    /**
     * Release MediaProjection
     */
    private fun releaseMediaProjection() {
        try {
            mediaProjection?.stop()
            mediaProjection = null
            Log.d(TAG, "MediaProjection released")
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing MediaProjection", e)
        }
    }

    /**
     * Create notification channel
     */
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Virtual Audio Cable",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Audio capture and injection service"
            }

            val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * Update foreground notification
     */
    private fun updateNotification() {
        val status = when {
            isCapturing.get() && isInjecting.get() -> "Capturing & Injecting"
            isCapturing.get() -> "Capturing"
            isInjecting.get() -> "Injecting"
            else -> "Idle"
        }

        val notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Virtual Audio Cable")
            .setContentText(status)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    /**
     * Broadcast status changed
     */
    private fun broadcastStatusChanged() {
        val intent = Intent(BROADCAST_STATUS_CHANGED).apply {
            putExtra(EXTRA_IS_CAPTURING, isCapturing.get())
            putExtra(EXTRA_IS_INJECTING, isInjecting.get())
        }
        sendBroadcast(intent)
    }

    /**
     * Broadcast audio levels
     */
    private fun broadcastAudioLevels(data: ByteArray, numBytes: Int) {
        try {
            // Calculate audio level (RMS)
            var sum = 0L
            for (i in 0 until numBytes step 2) {
                val sample = ((data[i + 1].toInt() and 0xFF) shl 8) or (data[i].toInt() and 0xFF)
                sum += sample.toLong() * sample.toLong()
            }
            val rms = Math.sqrt((sum / (numBytes / 2)).toDouble()).toFloat()
            val level = (rms / 32768f).coerceIn(0f, 1f)

            val intent = Intent(BROADCAST_AUDIO_LEVELS).apply {
                putExtra(EXTRA_AUDIO_LEVELS, level)
            }
            sendBroadcast(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error broadcasting audio levels", e)
        }
    }

    /**
     * Broadcast error
     */
    private fun broadcastError(message: String) {
        val intent = Intent(BROADCAST_ERROR).apply {
            putExtra(EXTRA_ERROR_MESSAGE, message)
        }
        sendBroadcast(intent)
    }

    /**
     * Get current statistics
     */
    fun getStatistics(): ServiceStatistics {
        return ServiceStatistics(
            isCapturing = isCapturing.get(),
            isInjecting = isInjecting.get(),
            captureStats = audioCaptureEngine?.getStatistics(),
            injectionStats = injectionEngine?.getStatistics(),
            oboeStats = oboeProcessor?.getStatistics()
        )
    }

    /**
     * Data class for service statistics
     */
    data class ServiceStatistics(
        val isCapturing: Boolean,
        val isInjecting: Boolean,
        val captureStats: AudioCaptureEngine.CaptureStatistics?,
        val injectionStats: InjectionEngine.InjectionStatistics?,
        val oboeStats: OboeProcessor.ProcessorStatistics?
    )
}

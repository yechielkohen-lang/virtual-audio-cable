package com.virtualcable.permissions

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * PermissionsManager: Handles all required permissions for Virtual Audio Cable
 *
 * Required Permissions:
 * - RECORD_AUDIO: Required for AudioRecord to capture audio
 * - FOREGROUND_SERVICE: Required to run foreground service
 * - MODIFY_AUDIO_SETTINGS: Required to modify audio routing
 * - MEDIA_CONTENT_CONTROL: Required for media control
 * - QUERY_ALL_PACKAGES: Required to list installed apps (Android 11+)
 */
class PermissionsManager(private val context: Context) {
    companion object {
        private const val TAG = "PermissionsManager"

        // Required permissions
        private val REQUIRED_PERMISSIONS = listOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.MODIFY_AUDIO_SETTINGS,
            Manifest.permission.MEDIA_CONTENT_CONTROL
        )

        // Foreground service permission (Android 12+)
        private val FOREGROUND_SERVICE_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            listOf(Manifest.permission.FOREGROUND_SERVICE)
        } else {
            emptyList()
        }

        // Query all packages permission (Android 11+)
        private val QUERY_PACKAGES_PERMISSIONS = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            listOf(Manifest.permission.QUERY_ALL_PACKAGES)
        } else {
            emptyList()
        }

        // All permissions combined
        private val ALL_PERMISSIONS = (REQUIRED_PERMISSIONS + FOREGROUND_SERVICE_PERMISSIONS + QUERY_PACKAGES_PERMISSIONS).distinct()
    }

    private var onPermissionsGranted: (() -> Unit)? = null
    private var onPermissionsDenied: ((List<String>) -> Unit)? = null

    /**
     * Create permission launcher for requesting permissions
     */
    fun createPermissionLauncher(activity: Activity): ActivityResultLauncher<Array<String>> {
        return activity.registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { permissions ->
            handlePermissionResult(permissions)
        }
    }

    /**
     * Request all required permissions
     */
    fun requestAllPermissions(launcher: ActivityResultLauncher<Array<String>>) {
        val permissionsToRequest = getMissingPermissions()

        if (permissionsToRequest.isEmpty()) {
            Log.i(TAG, "All permissions already granted")
            onPermissionsGranted?.invoke()
            return
        }

        Log.d(TAG, "Requesting permissions: $permissionsToRequest")
        launcher.launch(permissionsToRequest.toTypedArray())
    }

    /**
     * Get list of permissions that are not yet granted
     */
    fun getMissingPermissions(): List<String> {
        return ALL_PERMISSIONS.filter { permission ->
            ContextCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED
        }
    }

    /**
     * Check if all required permissions are granted
     */
    fun hasAllPermissions(): Boolean {
        return getMissingPermissions().isEmpty()
    }

    /**
     * Check if specific permission is granted
     */
    fun hasPermission(permission: String): Boolean {
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Check if RECORD_AUDIO permission is granted
     */
    fun hasRecordAudioPermission(): Boolean {
        return hasPermission(Manifest.permission.RECORD_AUDIO)
    }

    /**
     * Check if FOREGROUND_SERVICE permission is granted
     */
    fun hasForegroundServicePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            hasPermission(Manifest.permission.FOREGROUND_SERVICE)
        } else {
            true  // Not required on older Android versions
        }
    }

    /**
     * Check if MODIFY_AUDIO_SETTINGS permission is granted
     */
    fun hasModifyAudioSettingsPermission(): Boolean {
        return hasPermission(Manifest.permission.MODIFY_AUDIO_SETTINGS)
    }

    /**
     * Check if QUERY_ALL_PACKAGES permission is granted
     */
    fun hasQueryAllPackagesPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            hasPermission(Manifest.permission.QUERY_ALL_PACKAGES)
        } else {
            true  // Not required on older Android versions
        }
    }

    /**
     * Handle permission request result
     */
    private fun handlePermissionResult(permissions: Map<String, Boolean>) {
        val grantedPermissions = permissions.filter { it.value }.keys.toList()
        val deniedPermissions = permissions.filter { !it.value }.keys.toList()

        Log.d(TAG, "Permission result - Granted: $grantedPermissions, Denied: $deniedPermissions")

        if (deniedPermissions.isEmpty()) {
            Log.i(TAG, "All permissions granted")
            onPermissionsGranted?.invoke()
        } else {
            Log.w(TAG, "Some permissions denied: $deniedPermissions")
            onPermissionsDenied?.invoke(deniedPermissions)
        }
    }

    /**
     * Set callbacks for permission results
     */
    fun setCallbacks(
        onGranted: (() -> Unit)? = null,
        onDenied: ((List<String>) -> Unit)? = null
    ) {
        this.onPermissionsGranted = onGranted
        this.onPermissionsDenied = onDenied
    }

    /**
     * Get permission status summary
     */
    fun getPermissionStatus(): PermissionStatus {
        return PermissionStatus(
            recordAudio = hasRecordAudioPermission(),
            foregroundService = hasForegroundServicePermission(),
            modifyAudioSettings = hasModifyAudioSettingsPermission(),
            queryAllPackages = hasQueryAllPackagesPermission(),
            allGranted = hasAllPermissions()
        )
    }

    /**
     * Get detailed permission info
     */
    fun getPermissionInfo(): String {
        val status = getPermissionStatus()
        return """
            Permission Status:
            - RECORD_AUDIO: ${if (status.recordAudio) "✓" else "✗"}
            - FOREGROUND_SERVICE: ${if (status.foregroundService) "✓" else "✗"}
            - MODIFY_AUDIO_SETTINGS: ${if (status.modifyAudioSettings) "✓" else "✗"}
            - QUERY_ALL_PACKAGES: ${if (status.queryAllPackages) "✓" else "✗"}
            - All Granted: ${if (status.allGranted) "✓" else "✗"}
        """.trimIndent()
    }

    /**
     * Data class for permission status
     */
    data class PermissionStatus(
        val recordAudio: Boolean,
        val foregroundService: Boolean,
        val modifyAudioSettings: Boolean,
        val queryAllPackages: Boolean,
        val allGranted: Boolean
    )
}

/**
 * Extension function to get permissions manager
 */
fun Context.getPermissionsManager(): PermissionsManager {
    return PermissionsManager(this)
}

package com.virtualcable.audio

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.MediaProjectionManager
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts

/**
 * MediaProjectionManager: Handles MediaProjection lifecycle and permissions
 *
 * This manager:
 * 1. Requests user permission to capture screen/audio via system dialog
 * 2. Manages the MediaProjection instance lifecycle
 * 3. Provides callbacks for success/failure
 * 4. Handles cleanup and resource release
 */
@RequiresApi(Build.VERSION_CODES.Q)  // Android 10+
class MediaProjectionPermissionManager(
    private val context: Context
) {
    companion object {
        private const val TAG = "MediaProjectionManager"
    }

    private val projectionManager: MediaProjectionManager? by lazy {
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
    }

    private var mediaProjection: android.media.MediaProjection? = null
    private var projectionCallback: ProjectionCallback? = null

    // Callbacks
    private var onPermissionGranted: ((android.media.MediaProjection) -> Unit)? = null
    private var onPermissionDenied: (() -> Unit)? = null
    private var onError: ((String) -> Unit)? = null

    /**
     * Interface for projection lifecycle callbacks
     */
    interface ProjectionCallback {
        fun onProjectionStarted(projection: android.media.MediaProjection)
        fun onProjectionStopped()
    }

    /**
     * Create ActivityResultLauncher for MediaProjection permission request
     * Must be called during Activity initialization
     */
    fun createPermissionLauncher(activity: Activity): ActivityResultLauncher<Intent> {
        return activity.registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val intent = result.data
                if (intent != null) {
                    handlePermissionGranted(intent)
                } else {
                    handlePermissionDenied("No intent data received")
                }
            } else {
                handlePermissionDenied("User denied permission")
            }
        }
    }

    /**
     * Request MediaProjection permission from user
     */
    fun requestPermission(launcher: ActivityResultLauncher<Intent>) {
        try {
            val projectionManager = projectionManager
            if (projectionManager == null) {
                handleError("MediaProjectionManager not available")
                return
            }

            Log.d(TAG, "Requesting MediaProjection permission")
            val intent = projectionManager.createScreenCaptureIntent()
            launcher.launch(intent)
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting permission", e)
            handleError("Failed to request permission: ${e.message}")
        }
    }

    /**
     * Handle successful permission grant
     */
    private fun handlePermissionGranted(intent: Intent) {
        try {
            val projectionManager = projectionManager
            if (projectionManager == null) {
                handleError("MediaProjectionManager not available")
                return
            }

            // Create MediaProjection from intent
            mediaProjection = projectionManager.getMediaProjection(Activity.RESULT_OK, intent)

            if (mediaProjection == null) {
                handleError("Failed to create MediaProjection")
                return
            }

            Log.i(TAG, "MediaProjection permission granted")

            // Set up projection callback
            mediaProjection?.registerCallback(
                MediaProjectionCallbackImpl(),
                null  // Handler - null means use current thread's looper
            )

            projectionCallback?.onProjectionStarted(mediaProjection!!)
            onPermissionGranted?.invoke(mediaProjection!!)
        } catch (e: Exception) {
            Log.e(TAG, "Error handling permission grant", e)
            handleError("Failed to create projection: ${e.message}")
        }
    }

    /**
     * Handle permission denial
     */
    private fun handlePermissionDenied(reason: String) {
        Log.w(TAG, "Permission denied: $reason")
        onPermissionDenied?.invoke()
    }

    /**
     * Handle errors
     */
    private fun handleError(message: String) {
        Log.e(TAG, message)
        onError?.invoke(message)
    }

    /**
     * Get current MediaProjection instance
     */
    fun getMediaProjection(): android.media.MediaProjection? = mediaProjection

    /**
     * Check if MediaProjection is active
     */
    fun isProjectionActive(): Boolean = mediaProjection != null

    /**
     * Stop and release MediaProjection
     */
    fun stopProjection() {
        try {
            mediaProjection?.unregisterCallback(null)
            mediaProjection?.stop()
            mediaProjection = null
            Log.i(TAG, "MediaProjection stopped and released")
            projectionCallback?.onProjectionStopped()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping projection", e)
        }
    }

    /**
     * Set callbacks
     */
    fun setCallbacks(
        onGranted: ((android.media.MediaProjection) -> Unit)? = null,
        onDenied: (() -> Unit)? = null,
        onError: ((String) -> Unit)? = null,
        projectionCallback: ProjectionCallback? = null
    ) {
        this.onPermissionGranted = onGranted
        this.onPermissionDenied = onDenied
        this.onError = onError
        this.projectionCallback = projectionCallback
    }

    /**
     * Internal callback for MediaProjection lifecycle
     */
    private inner class MediaProjectionCallbackImpl : android.media.MediaProjection.Callback() {
        override fun onStop() {
            Log.i(TAG, "MediaProjection stopped by system")
            mediaProjection = null
            projectionCallback?.onProjectionStopped()
        }
    }
}

/**
 * Extension function to safely request MediaProjection with error handling
 */
fun MediaProjectionPermissionManager.requestPermissionWithFallback(
    launcher: ActivityResultLauncher<Intent>,
    onError: (String) -> Unit
) {
    try {
        requestPermission(launcher)
    } catch (e: Exception) {
        Log.e("MediaProjectionManager", "Failed to request permission", e)
        onError("Failed to request MediaProjection permission: ${e.message}")
    }
}

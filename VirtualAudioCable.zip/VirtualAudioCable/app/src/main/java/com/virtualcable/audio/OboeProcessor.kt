package com.virtualcable.audio

import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

/**
 * OboeProcessor: Kotlin wrapper for C++ Oboe audio processor
 *
 * This class provides:
 * - Low-latency audio playback via Oboe/AAudio
 * - Circular buffer for PCM data storage
 * - Real-time audio processing callbacks
 * - JNI bridge to native C++ implementation
 */
class OboeProcessor(
    private val sampleRate: Int = 48000,
    private val channelCount: Int = 1
) {
    companion object {
        private const val TAG = "OboeProcessor"

        // Load native library
        init {
            try {
                System.loadLibrary("oboe_processor")
                Log.i(TAG, "Native library loaded successfully")
            } catch (e: UnsatisfiedLinkError) {
                Log.e(TAG, "Failed to load native library", e)
            }
        }

        // Native methods
        private external fun createProcessor(sampleRate: Int, channelCount: Int): Long
        private external fun startPlayback(processorHandle: Long): Int
        private external fun stopPlayback(processorHandle: Long): Int
        private external fun writeAudioData(processorHandle: Long, data: ShortArray, numFrames: Int)
        private external fun getAvailableFrames(processorHandle: Long): Int
        private external fun getLatencyMs(processorHandle: Long): Int
        private external fun isPlaying(processorHandle: Long): Boolean
        private external fun clearBuffer(processorHandle: Long)
        private external fun destroyProcessor(processorHandle: Long)
    }

    private var processorHandle: Long = 0
    private val isInitialized = AtomicBoolean(false)
    private val isPlaying = AtomicBoolean(false)

    init {
        try {
            processorHandle = createProcessor(sampleRate, channelCount)
            if (processorHandle != 0L) {
                isInitialized.set(true)
                Log.i(TAG, "OboeProcessor initialized: handle=$processorHandle")
            } else {
                Log.e(TAG, "Failed to create processor")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing OboeProcessor", e)
        }
    }

    /**
     * Start audio playback
     * @return 0 if successful, non-zero error code otherwise
     */
    fun startPlayback(): Int {
        if (!isInitialized.get()) {
            Log.w(TAG, "Processor not initialized")
            return -1
        }

        return try {
            val result = startPlayback(processorHandle)
            if (result == 0) {
                isPlaying.set(true)
                Log.i(TAG, "Playback started")
            } else {
                Log.e(TAG, "Failed to start playback: error=$result")
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "Error starting playback", e)
            -1
        }
    }

    /**
     * Stop audio playback
     * @return 0 if successful, non-zero error code otherwise
     */
    fun stopPlayback(): Int {
        if (!isInitialized.get()) {
            Log.w(TAG, "Processor not initialized")
            return -1
        }

        return try {
            val result = stopPlayback(processorHandle)
            if (result == 0) {
                isPlaying.set(false)
                Log.i(TAG, "Playback stopped")
            } else {
                Log.e(TAG, "Failed to stop playback: error=$result")
            }
            result
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping playback", e)
            -1
        }
    }

    /**
     * Write audio data to the processor buffer
     * Data should be 16-bit PCM mono or stereo
     *
     * @param audioData 16-bit PCM audio samples
     * @param numFrames Number of audio frames (samples per channel)
     */
    fun writeAudioData(audioData: ShortArray, numFrames: Int) {
        if (!isInitialized.get()) {
            Log.w(TAG, "Processor not initialized")
            return
        }

        if (audioData.size < numFrames * channelCount) {
            Log.w(TAG, "Audio data size mismatch: expected=${numFrames * channelCount}, actual=${audioData.size}")
            return
        }

        try {
            writeAudioData(processorHandle, audioData, numFrames)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing audio data", e)
        }
    }

    /**
     * Write audio data from ByteArray (16-bit PCM)
     *
     * @param audioData 16-bit PCM audio as bytes (little-endian)
     */
    fun writeAudioDataFromBytes(audioData: ByteArray) {
        if (!isInitialized.get()) {
            Log.w(TAG, "Processor not initialized")
            return
        }

        try {
            // Convert ByteArray to ShortArray (little-endian)
            val shortArray = ShortArray(audioData.size / 2)
            for (i in shortArray.indices) {
                shortArray[i] = ((audioData[i * 2 + 1].toInt() and 0xFF) shl 8 or
                        (audioData[i * 2].toInt() and 0xFF)).toShort()
            }

            val numFrames = shortArray.size / channelCount
            writeAudioData(processorHandle, shortArray, numFrames)
        } catch (e: Exception) {
            Log.e(TAG, "Error writing audio data from bytes", e)
        }
    }

    /**
     * Get number of available frames in the buffer
     * @return Number of frames ready to be played
     */
    fun getAvailableFrames(): Int {
        if (!isInitialized.get()) {
            return 0
        }

        return try {
            getAvailableFrames(processorHandle)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting available frames", e)
            0
        }
    }

    /**
     * Get estimated latency in milliseconds
     * @return Latency in ms
     */
    fun getLatencyMs(): Int {
        if (!isInitialized.get()) {
            return 0
        }

        return try {
            getLatencyMs(processorHandle)
        } catch (e: Exception) {
            Log.e(TAG, "Error getting latency", e)
            0
        }
    }

    /**
     * Check if playback is currently active
     * @return true if playing, false otherwise
     */
    fun isPlaying(): Boolean {
        if (!isInitialized.get()) {
            return false
        }

        return try {
            isPlaying(processorHandle)
        } catch (e: Exception) {
            Log.e(TAG, "Error checking playback status", e)
            false
        }
    }

    /**
     * Clear the audio buffer (silence)
     */
    fun clearBuffer() {
        if (!isInitialized.get()) {
            Log.w(TAG, "Processor not initialized")
            return
        }

        try {
            clearBuffer(processorHandle)
            Log.d(TAG, "Buffer cleared")
        } catch (e: Exception) {
            Log.e(TAG, "Error clearing buffer", e)
        }
    }

    /**
     * Release resources and destroy processor
     */
    fun destroy() {
        if (!isInitialized.getAndSet(false)) {
            return
        }

        try {
            stopPlayback()
            destroyProcessor(processorHandle)
            processorHandle = 0
            Log.i(TAG, "OboeProcessor destroyed")
        } catch (e: Exception) {
            Log.e(TAG, "Error destroying processor", e)
        }
    }

    /**
     * Get processor statistics
     */
    fun getStatistics(): ProcessorStatistics {
        return ProcessorStatistics(
            isInitialized = isInitialized.get(),
            isPlaying = isPlaying.get(),
            availableFrames = getAvailableFrames(),
            latencyMs = getLatencyMs(),
            sampleRate = sampleRate,
            channelCount = channelCount
        )
    }

    /**
     * Data class for processor statistics
     */
    data class ProcessorStatistics(
        val isInitialized: Boolean,
        val isPlaying: Boolean,
        val availableFrames: Int,
        val latencyMs: Int,
        val sampleRate: Int,
        val channelCount: Int
    )
}

/**
 * Extension function to safely write audio data with error handling
 */
fun OboeProcessor.writeAudioDataSafely(audioData: ShortArray, numFrames: Int) {
    try {
        if (this.isPlaying()) {
            this.writeAudioData(audioData, numFrames)
        }
    } catch (e: Exception) {
        Log.e("OboeProcessor", "Error writing audio data safely", e)
    }
}

/**
 * Extension function to get processor info as string
 */
fun OboeProcessor.getInfoString(): String {
    val stats = this.getStatistics()
    return """
        OboeProcessor Status:
        - Initialized: ${stats.isInitialized}
        - Playing: ${stats.isPlaying}
        - Available Frames: ${stats.availableFrames}
        - Latency: ${stats.latencyMs} ms
        - Sample Rate: ${stats.sampleRate} Hz
        - Channels: ${stats.channelCount}
    """.trimIndent()
}
